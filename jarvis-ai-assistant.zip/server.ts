import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// Helper to get GoogleGenAI client safely
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey.trim() === '' || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health & Diagnostics endpoint
app.get('/api/health', (req: Request, res: Response) => {
  const hasKey = !!(
    process.env.GEMINI_API_KEY &&
    process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY' &&
    process.env.GEMINI_API_KEY.trim().length > 0
  );

  res.json({
    status: 'ONLINE',
    system: 'J.A.R.V.I.S. Core OS v4.8',
    aiOnline: hasKey,
    model: 'gemini-3.1-flash-lite',
    fallbackModel: 'gemini-3.8-flash',
    ttsModel: 'gemini-3.8-flash-lite-tts',
    hasGeminiKey: hasKey,
    timestamp: new Date().toISOString(),
    supportedLanguages: ['English', 'Hindi', 'Hinglish'],
    voiceSynthesizer: hasKey ? 'Gemini 3.8 Neural TTS + Web Speech Backup' : 'Web Speech Engine (Client-side)',
  });
});

// Chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const {
      message,
      history = [],
      languageMode = 'auto',
      personality = 'jarvis',
      assistantName = 'JARVIS',
      userName = 'Sir',
    } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message text is required.' });
      return;
    }

    const ai = getGeminiClient();

    // Check if Gemini API key is configured
    if (!ai) {
      res.status(400).json({
        error: 'Missing GEMINI_API_KEY',
        reply: `Pardon me, ${userName}. The GEMINI_API_KEY is not configured in the server environment. Please attach your API key in the AI Studio Settings > Secrets panel to enable real neural reasoning.`,
      });
      return;
    }

    // Build personality instructions
    let personalityPrompt = `You are ${assistantName}, a world-class, ultra-sophisticated AI inspired by Tony Stark's JARVIS.
You address the user respectfully as "${userName}" (or Sir/Ma'am).
You are witty, poised, brilliantly competent, and proactive.`;

    if (personality === 'tech_butler') {
      personalityPrompt = `You are ${assistantName}, an impeccably formal, hyper-efficient digital butler. Extremely concise, analytical, and courteous.`;
    } else if (personality === 'companion') {
      personalityPrompt = `You are ${assistantName}, a warm, empathetic, and witty AI companion and co-pilot who loves solving problems and chatting.`;
    }

    // Multilingual instructions tailored to requested languageMode
    let languageRule = '';
    if (languageMode === 'hindi') {
      languageRule = `CRITICAL MANDATE: The user explicitly selected HINDI. You MUST reply completely in fluent, respectful, and elegant Devanagari Hindi (हिन्दी). Do NOT reply in English. (e.g. "नमस्ते ${userName}, सभी प्रणालियाँ कार्यरत हैं। मैं आपकी क्या सेवा कर सकता हूँ?").`;
    } else if (languageMode === 'hinglish') {
      languageRule = `CRITICAL MANDATE: The user explicitly selected HINGLISH. You MUST reply completely in charismatic, natural conversational Hinglish (Hindi words written in Latin/English script, smoothly combined with English technical terms). Do NOT reply in Devanagari script, and do NOT reply in pure English. (e.g. "Bilkul ${userName}, sabhi systems green hain! Aaj hum kis project par kaam kar rahe hain? I am ready for your command.").`;
    } else if (languageMode === 'english') {
      languageRule = `CRITICAL MANDATE: The user explicitly selected ENGLISH. You MUST reply in crisp, articulate, witty British-Stark tech English.`;
    } else {
      // Auto mode
      languageRule = `AUTOMATIC LANGUAGE ADAPTATION:
- If the user writes in Devanagari script (e.g., नमस्ते, क्या हाल है): Respond completely in fluent, polite Devanagari Hindi (हिन्दी).
- If the user writes in Hinglish (e.g., "Kya haal hai", "kaisa chal raha hai", "batao", "theek hai"): Respond in charismatic, natural Hinglish in Latin/English alphabet.
- If the user writes in English: Respond in polished British-Stark English.
- Always mirror the user's language style with authentic flair.`;
    }

    const languageInstruction = `
MULTILINGUAL DIRECTIVE:
You are exceptionally fluent in 3 language styles: English, Hinglish, and Hindi.
${languageRule}

CRITICAL RULES:
- Never break character as ${assistantName}.
- Keep spoken or conversational answers punchy and enjoyable to listen to via text-to-speech.
- Use formatting (bullet points, short code blocks) when explaining technical details or steps.
`;

    const systemInstruction = `${personalityPrompt}\n${languageInstruction}`;

    // Format previous history for Gemini
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const item of history.slice(-8)) {
        if (item && (item.role === 'user' || item.role === 'assistant' || item.role === 'model')) {
          const text = (item.content || item.text || '').trim();
          if (text) {
            contents.push({
              role: item.role === 'assistant' ? 'model' : 'user',
              parts: [{ text }],
            });
          }
        }
      }
    }

    // Add current user prompt
    contents.push({
      role: 'user',
      parts: [{ text: message.trim() }],
    });

    // Models priority: Use fast free-tier compatible gemini-3.1-flash-lite first, then gemini-flash-latest, then gemini-3.8-flash
    const CANDIDATE_MODELS = ['gemini-3.1-flash-lite', 'gemini-flash-latest', 'gemini-3.8-flash'];
    let textOutput = '';
    let lastError: any = null;

    for (const candidateModel of CANDIDATE_MODELS) {
      try {
        const response = await ai.models.generateContent({
          model: candidateModel,
          contents,
          config: {
            systemInstruction,
            temperature: 0.7,
          },
        });
        textOutput = response.text || '';
        if (textOutput) {
          break;
        }
      } catch (err: any) {
        console.warn(`Model ${candidateModel} failed with status ${err?.status}:`, err?.message);
        lastError = err;
      }
    }

    if (!textOutput) {
      const statusText = lastError?.status ? ` (Status ${lastError.status})` : '';
      const detailedMessage = lastError?.message || 'Neural models unavailable';
      res.status(500).json({
        error: detailedMessage,
        reply: `Pardon me, ${userName}. The neural link reported an API error${statusText}: ${detailedMessage}. Please try again shortly.`,
      });
      return;
    }

    let detectedLanguage: 'hindi' | 'hinglish' | 'english' = 'english';
    if (/[\u0900-\u097F]/.test(textOutput)) {
      detectedLanguage = 'hindi';
    } else if (
      /\b(kya|kaise|kaisa|theek|batao|karo|raha|rahi|hain|hoon|main|mera|meri|aaj|chalo|bilkul|shuru|karein|samjhao|sab|aapka|aapke|kuch|nahi|kar)\b/i.test(
        textOutput
      )
    ) {
      detectedLanguage = 'hinglish';
    }

    res.json({
      reply: textOutput,
      languageDetected: detectedLanguage,
      isFallback: false,
    });
  } catch (error: any) {
    console.error('JARVIS Chat Endpoint Error:', error);
    res.status(500).json({
      error: error?.message || 'Internal server error',
      reply: `Pardon me, Sir. A system exception occurred: ${error?.message || 'Unknown disturbance'}.`,
    });
  }
});

// Text-to-Speech endpoint using gemini-3.8-flash-lite-tts
app.post('/api/tts', async (req: Request, res: Response) => {
  try {
    const { text, voiceName = 'Fenrir' } = req.body;

    if (!text || typeof text !== 'string') {
      res.status(400).json({ error: 'Text to speak is required.' });
      return;
    }

    const ai = getGeminiClient();

    if (!ai) {
      // Signal client to use browser speech synthesis
      res.json({
        fallbackToBrowser: true,
        message: 'Neural TTS key not configured; using browser speech synthesis.',
      });
      return;
    }

    // Clean text for speech (strip markdown headers, asterisks, code blocks)
    const cleanedText = text
      .replace(/```[\s\S]*?```/g, 'Code block omitted for speech.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*#_~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .trim()
      .slice(0, 1000); // Keep reasonable length for audio synthesis

    if (!cleanedText) {
      res.json({ fallbackToBrowser: true });
      return;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [{ text: cleanedText }],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {
              voiceName: ['Puck', 'Charon', 'Kore', 'Fenrir', 'Zephyr'].includes(voiceName)
                ? voiceName
                : 'Fenrir',
            },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

    if (!base64Audio) {
      res.json({
        fallbackToBrowser: true,
        message: 'No audio stream returned; falling back to browser speech.',
      });
      return;
    }

    res.json({
      fallbackToBrowser: false,
      audioData: base64Audio,
      mimeType: 'audio/wav',
    });
  } catch (error: any) {
    console.error('JARVIS TTS Error:', error);
    // Graceful fallback to client browser speech synthesis
    res.json({
      fallbackToBrowser: true,
      error: error?.message || 'Neural speech unavailable.',
    });
  }
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`JARVIS Core Server operational on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start JARVIS Core Server:', err);
});
