export type LanguageMode = 'auto' | 'english' | 'hinglish' | 'hindi';

export type PersonalityMode = 'jarvis' | 'tech_butler' | 'companion';

export type GeminiVoice = 'Fenrir' | 'Zephyr' | 'Kore' | 'Puck' | 'Charon';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  languageDetected?: LanguageMode;
  audioUrl?: string; // cached base64 audio if generated
  isFallback?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
  languageMode: LanguageMode;
}

export interface JarvisSettings {
  assistantName: string;
  userName: string;
  userTitle: string;
  personality: PersonalityMode;
  defaultLanguage: LanguageMode;
  ttsVoice: GeminiVoice;
  browserVoiceUri?: string;
  useGeminiTTS: boolean;
  autoSpeak: boolean;
  speechRate: number;
  speechPitch: number;
  soundEffects: boolean;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: string;
  clearanceLevel: 'LEVEL 1' | 'LEVEL 4' | 'LEVEL 7' | 'ALPHA - STARK';
  avatar?: string;
  joinedAt: number;
}

export interface SystemTelemetry {
  coreIntegrity: number;
  neuralSync: number;
  cpuLoad: number;
  memoryUsage: number;
  batteryLevel: number | null;
  isCharging: boolean | null;
  latencyMs: number;
  status: 'ONLINE' | 'STANDBY' | 'SYNCING';
  uptimeSeconds: number;
}
