import React, { useState, useRef, useEffect } from 'react';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Languages,
  Sparkles,
  Bot,
  User as UserIcon,
  RotateCcw,
  AlertCircle,
  Radio,
} from 'lucide-react';
import { ChatMessage, JarvisSettings, LanguageMode } from '../types';
import { ArcReactorCore } from './ArcReactorCore';
import { voiceInput, voiceOutput, soundEffects } from '../services/speech';
import { requestNeuralTTS } from '../services/api';

interface ChatInterfaceProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => Promise<void>;
  isLoading: boolean;
  settings: JarvisSettings;
  activeLanguage: LanguageMode;
  onLanguageChange: (lang: LanguageMode) => void;
  isMuted: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({
  messages,
  onSendMessage,
  isLoading,
  settings,
  activeLanguage,
  onLanguageChange,
  isMuted,
}) => {
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [interimSpeech, setInterimSpeech] = useState('');
  const [micError, setMicError] = useState<string | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Track global voice output speaking state
  useEffect(() => {
    voiceOutput.subscribe((speaking) => {
      if (!speaking) {
        setSpeakingMessageId(null);
      }
    });
  }, []);

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading, interimSpeech]);

  // Suggested multilingual prompts
  const suggestions = [
    { label: 'Hinglish: Kya haal hai?', text: 'Kya haal hai JARVIS? Aaj ka kya plan hai?' },
    { label: 'Hindi: नमस्ते जार्विस', text: 'नमस्ते जार्विस! अपने सिस्टम का स्टेटस और मौसम बताओ।' },
    { label: 'Status Report', text: 'JARVIS, give me a complete operational status report.' },
    { label: 'Stark Protocol', text: 'Explain the Mark 85 nanotechnology armor suit in Hinglish.' },
  ];

  // Handle Voice Input Toggle
  const toggleListening = () => {
    setMicError(null);

    if (isListening) {
      voiceInput.stop();
      setIsListening(false);
      if (interimSpeech.trim()) {
        const textToSend = interimSpeech.trim();
        setInterimSpeech('');
        onSendMessage(textToSend);
      }
      return;
    }

    // Determine recognition language:
    let recognitionLang = 'en-IN';
    if (activeLanguage === 'hindi') {
      recognitionLang = 'hi-IN';
    } else if (activeLanguage === 'hinglish') {
      recognitionLang = 'hi-IN'; // Recognizes both Hindi and English words
    }

    voiceInput.start(recognitionLang, {
      onTranscript: (text, isFinal) => {
        setInterimSpeech(text);
        if (isFinal) {
          setInputText((prev) => (prev ? `${prev} ${text}` : text));
          setInterimSpeech('');
        }
      },
      onError: (err) => {
        setMicError(err);
        setIsListening(false);
        setInterimSpeech('');
      },
      onEnd: () => {
        setIsListening(false);
      },
    });

    setIsListening(true);
  };

  // Handle Form Submit
  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputText.trim() || interimSpeech.trim();
    if (!trimmed || isLoading) return;

    if (isListening) {
      voiceInput.stop();
      setIsListening(false);
    }

    setInputText('');
    setInterimSpeech('');
    await onSendMessage(trimmed);
  };

  // Text-To-Speech for specific message
  const handleSpeakMessage = async (msg: ChatMessage) => {
    if (isMuted) return;

    if (speakingMessageId === msg.id) {
      voiceOutput.stop();
      setSpeakingMessageId(null);
      return;
    }

    setSpeakingMessageId(msg.id);

    try {
      // 1. Try Gemini Neural TTS if user explicitly enabled it in settings
      if (settings.useGeminiTTS) {
        const ttsRes = await requestNeuralTTS(msg.content, settings.ttsVoice);
        if (!ttsRes.fallbackToBrowser && ttsRes.audioData) {
          await voiceOutput.playWavBase64(ttsRes.audioData, ttsRes.mimeType);
          return;
        }
      }

      // 2. Free voice output using the browser SpeechSynthesis API
      const isHindi =
        msg.languageDetected === 'hindi' || /[\u0900-\u097F]/.test(msg.content);
      const isHinglish =
        msg.languageDetected === 'hinglish' ||
        /\b(kya|kaise|kaisa|theek|batao|karo|raha|rahi|hain|hoon|main|mera|meri|aaj|chalo|bilkul|shuru|karein)\b/i.test(
          msg.content
        );

      const lang = isHindi ? 'hi-IN' : isHinglish ? 'en-IN' : 'en-US';

      await voiceOutput.speakBrowser(msg.content, {
        lang,
        voiceUri: settings.browserVoiceUri,
        rate: settings.speechRate,
        pitch: settings.speechPitch,
      });
    } catch (err) {
      console.warn('Speech playback failed:', err);
    } finally {
      setSpeakingMessageId(null);
    }
  };

  // Copy message text
  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const coreStatus = isListening
    ? 'listening'
    : isLoading
    ? 'thinking'
    : speakingMessageId
    ? 'speaking'
    : 'idle';

  return (
    <div className="flex-1 flex flex-col h-full bg-cyber-grid relative overflow-hidden">
      {/* Top Language Bar & Quick Stats */}
      <div className="border-b border-cyan-500/15 bg-gray-950/70 backdrop-blur-xs px-3 md:px-6 py-2 flex flex-wrap items-center justify-between gap-2 z-10">
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5 no-scrollbar">
          <span className="text-[10px] font-mono text-cyan-400/70 flex items-center gap-1 mr-1">
            <Languages className="w-3 h-3 text-cyan-400" />
            <span>LINGO:</span>
          </span>
          {(['auto', 'english', 'hinglish', 'hindi'] as LanguageMode[]).map((mode) => (
            <button
              key={mode}
              onClick={() => onLanguageChange(mode)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-mono tracking-wide uppercase transition-all ${
                activeLanguage === mode
                  ? 'bg-cyan-500/25 border border-cyan-400 text-cyan-300 font-bold shadow-[0_0_8px_rgba(6,182,212,0.3)]'
                  : 'bg-slate-900/50 border border-cyan-500/15 text-gray-400 hover:text-cyan-200 hover:border-cyan-500/30'
              }`}
            >
              {mode === 'auto'
                ? 'Auto'
                : mode === 'hinglish'
                ? 'Hinglish (हिंग्लिश)'
                : mode === 'hindi'
                ? 'हिन्दी (Hindi)'
                : 'English'}
            </button>
          ))}
        </div>

        <div className="hidden sm:flex items-center gap-3 text-[11px] font-mono text-cyan-500/70">
          <span>TTS: {settings.useGeminiTTS ? `Neural (${settings.ttsVoice})` : 'Browser'}</span>
          <span>•</span>
          <span>{settings.personality.toUpperCase()} MODE</span>
        </div>
      </div>

      {/* Mic error notice */}
      {micError && (
        <div className="mx-4 mt-2 p-2.5 rounded-lg bg-rose-950/80 border border-rose-500/40 text-rose-200 text-xs flex items-center justify-between gap-2 shadow-lg z-20">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{micError}</span>
          </div>
          <button
            onClick={() => setMicError(null)}
            className="text-xs underline text-rose-300 hover:text-white"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Conversation Stream */}
      <div className="flex-1 overflow-y-auto p-3 md:p-6 space-y-4">
        {messages.length === 0 ? (
          /* Empty state with glowing Arc Reactor */
          <div className="h-full min-h-[350px] flex flex-col items-center justify-center text-center p-4">
            <ArcReactorCore
              status={coreStatus}
              size="md"
              assistantName={settings.assistantName}
              onClick={toggleListening}
            />

            <h2 className="mt-5 font-orbitron text-lg md:text-xl font-bold tracking-wider text-cyan-200 glow-text-cyan">
              {settings.assistantName} PROTOCOL STANDBY
            </h2>
            <p className="mt-1 text-xs md:text-sm text-cyan-400/70 max-w-md font-rajdhani">
              Awaiting your voice directive or typed query, {settings.userTitle}. Fluent in English,
              Hinglish, and Hindi.
            </p>

            {/* Quick action chips */}
            <div className="mt-6 flex flex-wrap justify-center gap-2 max-w-lg">
              {suggestions.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => onSendMessage(s.text)}
                  className="px-3 py-1.5 rounded-lg bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 text-xs font-rajdhani tracking-wide transition-all shadow-sm hover:shadow-[0_0_12px_rgba(6,182,212,0.25)] flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  <span>{s.label}</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg) => {
            const isUser = msg.role === 'user';
            const isSpeakingThis = speakingMessageId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-3 max-w-3xl ${
                  isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
                }`}
              >
                {/* Avatar Icon */}
                <div
                  className={`w-8 h-8 rounded-full shrink-0 flex items-center justify-center border shadow-sm ${
                    isUser
                      ? 'bg-blue-900/60 border-blue-400 text-blue-200'
                      : 'bg-cyan-950/90 border-cyan-400 text-cyan-300 glow-cyan-sm'
                  }`}
                >
                  {isUser ? <UserIcon className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Bubble */}
                <div
                  className={`relative rounded-xl p-3.5 text-sm transition-all group ${
                    isUser
                      ? 'bg-blue-950/40 border border-blue-500/30 text-blue-100 rounded-tr-none'
                      : 'bg-gray-900/80 border border-cyan-500/30 text-cyan-100 rounded-tl-none shadow-[0_4px_15px_rgba(0,0,0,0.3)]'
                  } ${isSpeakingThis ? 'border-cyan-400 glow-cyan-md ring-1 ring-cyan-400' : ''}`}
                >
                  {/* Speaker animation indicator if speaking */}
                  {isSpeakingThis && (
                    <div className="flex items-center gap-1 text-[10px] font-mono text-cyan-300 mb-1.5 pb-1 border-b border-cyan-500/20">
                      <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
                      <span>{settings.assistantName} IS SPEAKING...</span>
                    </div>
                  )}

                  {/* Message Content */}
                  <div className="whitespace-pre-wrap leading-relaxed font-rajdhani text-sm md:text-base tracking-wide selection:bg-cyan-500 selection:text-black">
                    {msg.content}
                  </div>

                  {/* Message Footer: Actions & Timestamp */}
                  <div className="mt-2.5 pt-1.5 border-t border-cyan-500/10 flex items-center justify-between gap-3 text-[10px] font-mono text-cyan-400/60">
                    <span>
                      {new Date(msg.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>

                    <div className="flex items-center gap-1.5">
                      {/* Free Browser SpeechSynthesis Speaker Button */}
                      {!isUser && (
                        <button
                          onClick={() => handleSpeakMessage(msg)}
                          title={isSpeakingThis ? 'Stop voice playback' : 'Play voice output aloud (SpeechSynthesis)'}
                          className={`flex items-center gap-1 px-2 py-0.5 rounded border text-[10px] font-mono transition-all select-none ${
                            isSpeakingThis
                              ? 'bg-cyan-950 border-cyan-400 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.6)] animate-pulse font-bold'
                              : 'bg-slate-900/80 border-cyan-500/30 text-cyan-300 hover:text-cyan-100 hover:border-cyan-400 hover:bg-cyan-950/60'
                          }`}
                        >
                          {isSpeakingThis ? (
                            <>
                              <VolumeX className="w-3 h-3 text-cyan-300 animate-pulse" />
                              <span>STOP</span>
                            </>
                          ) : (
                            <>
                              <Volume2 className="w-3 h-3 text-cyan-400" />
                              <span>SPEAK</span>
                            </>
                          )}
                        </button>
                      )}

                      {/* Copy message */}
                      <button
                        onClick={() => handleCopy(msg.id, msg.content)}
                        title="Copy text"
                        className="p-1 text-gray-400 hover:text-cyan-300 rounded hover:bg-cyan-950/60 transition-colors"
                      >
                        {copiedId === msg.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })
        )}

        {/* Live speech preview if user is dictating */}
        {isListening && interimSpeech && (
          <div className="flex gap-3 max-w-3xl ml-auto flex-row-reverse animate-pulse">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <Mic className="w-4 h-4" />
            </div>
            <div className="rounded-xl p-3 text-sm bg-amber-950/30 border border-amber-500/40 text-amber-100 rounded-tr-none">
              <span className="text-[10px] font-mono text-amber-400 block mb-1">
                TRANSCRIBING SPEECH...
              </span>
              <p className="font-rajdhani">{interimSpeech}</p>
            </div>
          </div>
        )}

        {/* AI Thinking Indicator */}
        {isLoading && (
          <div className="flex gap-3 max-w-md mr-auto">
            <div className="w-8 h-8 rounded-full bg-cyan-950/90 border border-cyan-400 text-cyan-300 flex items-center justify-center animate-spin">
              <Bot className="w-4 h-4" />
            </div>
            <div className="rounded-xl p-3 bg-gray-900/90 border border-cyan-500/40 text-cyan-300 rounded-tl-none flex items-center gap-2 glow-cyan-sm">
              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              <span className="text-xs font-orbitron tracking-wider">
                COMPUTING NEURAL RESPONSE...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Floating Active Voice Bar */}
      {isListening && (
        <div className="bg-amber-950/80 border-t border-b border-amber-500/40 px-4 py-2 flex items-center justify-between text-xs font-mono text-amber-300 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
            <span>LISTENING FOR DICTATION... Speak in Hindi, Hinglish, or English</span>
          </div>
          <button
            onClick={toggleListening}
            className="px-2 py-0.5 rounded bg-amber-500/20 hover:bg-amber-500/40 border border-amber-400/50 text-[11px]"
          >
            DONE / SEND
          </button>
        </div>
      )}

      {/* Bottom Input Console */}
      <div className="p-3 md:p-4 border-t border-cyan-500/20 bg-gray-950/90 backdrop-blur-md z-10">
        <form
          onSubmit={handleSend}
          className="relative flex items-end gap-2 bg-slate-900/80 border border-cyan-500/30 rounded-2xl p-1.5 focus-within:border-cyan-400 focus-within:ring-1 focus-within:ring-cyan-400/60 transition-all shadow-[0_0_15px_rgba(0,0,0,0.5)]"
        >
          {/* Microphone button */}
          <button
            type="button"
            onClick={toggleListening}
            title={isListening ? 'Stop listening' : 'Start voice input (Hindi, Hinglish, English)'}
            className={`p-2.5 md:p-3 rounded-xl transition-all shrink-0 flex items-center justify-center ${
              isListening
                ? 'bg-amber-500 text-black shadow-[0_0_20px_rgba(245,158,11,0.8)] animate-pulse'
                : 'bg-cyan-950/60 text-cyan-300 hover:bg-cyan-900/60 hover:text-cyan-100 border border-cyan-500/30'
            }`}
          >
            {isListening ? (
              <MicOff className="w-5 h-5" />
            ) : (
              <Mic className="w-5 h-5 text-cyan-300" />
            )}
          </button>

          {/* Textarea input */}
          <textarea
            ref={inputRef}
            rows={1}
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={`Ask ${settings.assistantName} anything in Hindi, Hinglish, or English...`}
            className="flex-1 bg-transparent border-0 text-cyan-50 placeholder:text-gray-500 text-sm md:text-base font-rajdhani tracking-wide focus:outline-hidden resize-none py-2 px-2 max-h-32"
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim() && !interimSpeech.trim()}
            className="p-2.5 md:p-3 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-30 disabled:hover:bg-cyan-500 text-black font-bold transition-all shrink-0 shadow-[0_0_15px_rgba(6,182,212,0.5)] active:scale-95 flex items-center justify-center"
          >
            <Send className="w-4 h-4 md:w-5 md:h-5" />
          </button>
        </form>

        <div className="flex items-center justify-between mt-2 px-1 text-[10px] font-mono text-cyan-500/50">
          <span>HINT: Press Enter to send, Shift+Enter for new line</span>
          <span className="hidden sm:inline">VOICE ENGINE: WEBSPEECH + GEMINI 3.8</span>
        </div>
      </div>
    </div>
  );
};
