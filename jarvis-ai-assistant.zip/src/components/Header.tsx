import React, { useEffect, useState } from 'react';
import {
  ShieldAlert,
  Cpu,
  Wifi,
  Volume2,
  VolumeX,
  Sliders,
  HelpCircle,
  Menu,
  User,
  Radio,
} from 'lucide-react';
import { JarvisSettings, UserProfile } from '../types';

interface HeaderProps {
  settings: JarvisSettings;
  user: UserProfile | null;
  hasGeminiKey: boolean;
  onOpenSettings: () => void;
  onOpenAuth: () => void;
  onOpenSetup: () => void;
  onToggleSidebar: () => void;
  onToggleMute: () => void;
  isMuted: boolean;
  activeTab: 'chat' | 'dashboard' | 'protocols';
  setActiveTab: (tab: 'chat' | 'dashboard' | 'protocols') => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  user,
  hasGeminiKey,
  onOpenSettings,
  onOpenAuth,
  onOpenSetup,
  onToggleSidebar,
  onToggleMute,
  isMuted,
  activeTab,
  setActiveTab,
}) => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-30 w-full border-b border-cyan-500/20 bg-gray-950/85 backdrop-blur-md px-3 md:px-6 py-2.5 flex items-center justify-between gap-3 shadow-[0_4px_20px_rgba(0,0,0,0.5)]">
      {/* Left: Mobile hamburger & Logo */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          aria-label="Toggle navigation drawer"
          className="md:hidden p-2 rounded-lg border border-cyan-500/30 text-cyan-400 hover:bg-cyan-950/60 transition-colors"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-full border border-cyan-400 bg-cyan-950/60 shadow-[0_0_12px_rgba(6,182,212,0.6)]">
            <Radio className="w-4 h-4 text-cyan-300 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-orbitron font-extrabold text-base md:text-lg tracking-wider text-cyan-300 glow-text-cyan">
                {settings.assistantName}
              </span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-500/40 text-cyan-400 tracking-wider hidden sm:inline-block">
                MK-VI
              </span>
            </div>
            <div className="text-[10px] text-cyan-400/60 font-mono tracking-tight flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
              <span>ONLINE</span>
              <span className="text-cyan-600">|</span>
              <span className="hidden sm:inline">MULTILINGUAL (EN/HI)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Center Nav tabs (Desktop/Tablet) */}
      <nav className="hidden md:flex items-center gap-1 bg-gray-900/70 border border-cyan-500/20 p-1 rounded-xl">
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-orbitron tracking-wider transition-all ${
            activeTab === 'dashboard'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
              : 'text-gray-400 hover:text-cyan-200'
          }`}
        >
          DASHBOARD
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-orbitron tracking-wider transition-all ${
            activeTab === 'chat'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
              : 'text-gray-400 hover:text-cyan-200'
          }`}
        >
          NEURAL CHAT
        </button>
        <button
          onClick={() => setActiveTab('protocols')}
          className={`px-3.5 py-1.5 rounded-lg text-xs font-orbitron tracking-wider transition-all ${
            activeTab === 'protocols'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
              : 'text-gray-400 hover:text-cyan-200'
          }`}
        >
          PROTOCOLS
        </button>
      </nav>

      {/* Right: Telemetry & Controls */}
      <div className="flex items-center gap-2 md:gap-3">
        {/* Live HUD Clock */}
        <div className="hidden lg:flex flex-col items-end font-mono text-[11px] text-cyan-400/80 bg-cyan-950/30 border border-cyan-500/20 px-2.5 py-1 rounded-md">
          <span className="text-cyan-300 font-semibold">{time}</span>
          <span className="text-[9px] text-cyan-500/60 tracking-wider">STARK-NET LOC</span>
        </div>

        {/* Neural Engine Indicator */}
        <button
          onClick={onOpenSetup}
          title={hasGeminiKey ? 'Gemini 3.8 Neural Engine Connected' : 'Simulated Engine Active (Click to view setup)'}
          className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-mono transition-all ${
            hasGeminiKey
              ? 'border-emerald-500/40 bg-emerald-950/30 text-emerald-300 hover:bg-emerald-900/40'
              : 'border-amber-500/40 bg-amber-950/30 text-amber-300 hover:bg-amber-900/40'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span className="text-[11px]">{hasGeminiKey ? 'GEMINI FLASH' : 'KEY REQUIRED'}</span>
        </button>

        {/* Audio Mute / Unmute */}
        <button
          onClick={onToggleMute}
          title={isMuted ? 'Unmute voice output' : 'Mute voice output'}
          className={`p-2 rounded-lg border transition-all ${
            isMuted
              ? 'border-rose-500/40 bg-rose-950/30 text-rose-300 hover:bg-rose-900/40'
              : 'border-cyan-500/30 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50 shadow-[0_0_8px_rgba(6,182,212,0.2)]'
          }`}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Settings button */}
        <button
          onClick={onOpenSettings}
          title="Assistant Settings & Voice Preferences"
          className="p-2 rounded-lg border border-cyan-500/30 bg-cyan-950/40 text-cyan-300 hover:bg-cyan-900/50 hover:border-cyan-400 transition-all shadow-[0_0_8px_rgba(6,182,212,0.2)]"
        >
          <Sliders className="w-4 h-4" />
        </button>

        {/* User Auth / Clearance Profile Button */}
        <button
          onClick={onOpenAuth}
          className="flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-lg border border-cyan-500/30 bg-cyan-950/40 hover:bg-cyan-900/50 transition-all group"
          title="User Profile & Clearance Authentication"
        >
          <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center text-[10px] font-bold text-black font-orbitron group-hover:shadow-[0_0_8px_rgba(6,182,212,0.8)]">
            {user ? user.name.slice(0, 2).toUpperCase() : 'ST'}
          </div>
          <span className="hidden sm:inline text-xs font-rajdhani font-semibold text-cyan-200">
            {user ? user.name : 'Stark User'}
          </span>
        </button>
      </div>
    </header>
  );
};
