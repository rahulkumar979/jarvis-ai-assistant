import React from 'react';
import {
  Terminal,
  Shield,
  Zap,
  Globe,
  Code,
  Radio,
  Sparkles,
  Play,
  RotateCw,
} from 'lucide-react';
import { soundEffects } from '../services/speech';

interface ProtocolsViewProps {
  onExecutePrompt: (prompt: string) => void;
  assistantName: string;
}

export const ProtocolsView: React.FC<ProtocolsViewProps> = ({
  onExecutePrompt,
  assistantName,
}) => {
  const categories = [
    {
      title: 'BILINGUAL & HINGLISH PROTOCOLS',
      icon: Globe,
      items: [
        {
          name: 'Hinglish Casual Chat Protocol',
          prompt: `${assistantName}, chalo thodi baatein karte hain Hinglish mein. Mujhe batao aaj ke top tech innovations kya hain aur future kaisa lag raha hai?`,
          desc: 'Fluid Hinglish conversation on trending AI and tech developments.',
        },
        {
          name: 'हिन्दी ज्ञान संवाद (Hindi Intellectual Dialogue)',
          prompt: `${assistantName}, नमस्ते। कृपया मुझे क्वांटम कंप्यूटिंग और आर्टिफिशियल इंटेलिजेंस के भविष्य के बारे में सरल और स्पष्ट हिन्दी में समझाइए।`,
          desc: 'High-level science and technology explanation in refined Hindi.',
        },
        {
          name: 'English-to-Hinglish Slang Transformer',
          prompt: `${assistantName}, translate this formal sentence into charismatic Tony Stark Hinglish: "We have analyzed the tactical data and recommend an immediate deployment of countermeasures."`,
          desc: 'Demonstrates cross-cultural Stark wit and Hinglish translation.',
        },
      ],
    },
    {
      title: 'STARK ENGINEERING & CODE PROTOCOLS',
      icon: Code,
      items: [
        {
          name: 'Iron Man Mark 85 Telemetry Analysis',
          prompt: `${assistantName}, conduct a comprehensive technical analysis of the Mark 85 nanotech armor suit, including power dissipation and nanite replenishment rates.`,
          desc: 'In-depth fictional Stark engineering review with witty persona.',
        },
        {
          name: 'Full-Stack Architecture Blueprints',
          prompt: `${assistantName}, provide a production-ready architectural breakdown for a scalable real-time AI application using TypeScript and microservices.`,
          desc: 'Clean technical software engineering advice and clean architecture.',
        },
      ],
    },
    {
      title: 'DAILY PRODUCTIVITY & EXECUTIVE PROTOCOLS',
      icon: Zap,
      items: [
        {
          name: 'House Party Protocol (Executive Briefing)',
          prompt: `${assistantName}, execute protocol House Party. Give me my executive morning briefing, top priority milestones, and a motivating Stark quote.`,
          desc: 'Energetic, motivational executive day starter.',
        },
        {
          name: 'Crisis Mitigation Protocol (Clean Thinker)',
          prompt: `${assistantName}, I have a high-stakes engineering deadline in 24 hours with conflicting requirements. Give me a step-by-step triage protocol to de-stress and execute.`,
          desc: 'Calm, calculated problem solving and risk triage.',
        },
      ],
    },
  ];

  const handleLaunch = (prompt: string) => {
    soundEffects.playHudChime();
    onExecutePrompt(prompt);
  };

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 bg-cyber-grid">
      <div className="flex items-center justify-between border-b border-cyan-500/20 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <Terminal className="w-6 h-6 text-cyan-400" />
            <h1 className="text-xl md:text-2xl font-orbitron font-extrabold text-cyan-100 tracking-wider glow-text-cyan">
              TACTICAL PROTOCOL REGISTRY
            </h1>
          </div>
          <p className="text-xs md:text-sm font-rajdhani text-cyan-400/70 mt-1">
            Pre-configured command routines optimized for {assistantName}'s multilingual neural matrix.
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-cyan-400 bg-cyan-950/60 border border-cyan-500/30 px-3 py-1.5 rounded-lg">
          <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
          <span>7 ACTIVE PROTOCOLS</span>
        </div>
      </div>

      <div className="space-y-6">
        {categories.map((cat, cIdx) => {
          const CatIcon = cat.icon;
          return (
            <div key={cIdx} className="space-y-3">
              <div className="flex items-center gap-2 text-xs font-orbitron text-cyan-300 font-bold tracking-wider">
                <CatIcon className="w-4 h-4 text-cyan-400" />
                <span>{cat.title}</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4">
                {cat.items.map((item, iIdx) => (
                  <div
                    key={iIdx}
                    className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/20 hover:border-cyan-400 hover:bg-slate-900/60 transition-all flex flex-col justify-between gap-3 group shadow-[0_4px_15px_rgba(0,0,0,0.3)] hover:shadow-[0_0_20px_rgba(6,182,212,0.15)]"
                  >
                    <div>
                      <h3 className="font-orbitron font-semibold text-sm text-cyan-100 group-hover:text-cyan-300 transition-colors">
                        {item.name}
                      </h3>
                      <p className="mt-1.5 text-xs text-cyan-300/70 font-rajdhani leading-relaxed">
                        {item.desc}
                      </p>
                    </div>

                    <button
                      onClick={() => handleLaunch(item.prompt)}
                      className="mt-2 w-full py-2 px-3 rounded-lg bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-500/30 hover:border-cyan-400 text-cyan-300 font-orbitron text-xs tracking-wider transition-all flex items-center justify-center gap-2 group-hover:shadow-[0_0_10px_rgba(6,182,212,0.3)]"
                    >
                      <Play className="w-3.5 h-3.5 fill-cyan-400 text-cyan-400" />
                      <span>INITIALIZE</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
