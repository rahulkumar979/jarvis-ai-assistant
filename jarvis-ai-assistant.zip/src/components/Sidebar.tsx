import React, { useState } from 'react';
import {
  MessageSquare,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Search,
  LayoutDashboard,
  Terminal,
  Settings,
  ChevronRight,
  Shield,
  HelpCircle,
} from 'lucide-react';
import { ChatSession, UserProfile } from '../types';

interface SidebarProps {
  sessions: ChatSession[];
  activeSessionId: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onRenameSession: (id: string, newTitle: string) => void;
  isOpen: boolean;
  onClose: () => void;
  activeTab: 'chat' | 'dashboard' | 'protocols';
  setActiveTab: (tab: 'chat' | 'dashboard' | 'protocols') => void;
  onOpenSettings: () => void;
  onOpenSetup: () => void;
  user: UserProfile | null;
}

export const Sidebar: React.FC<SidebarProps> = ({
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onRenameSession,
  isOpen,
  onClose,
  activeTab,
  setActiveTab,
  onOpenSettings,
  onOpenSetup,
  user,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredSessions = sessions.filter((s) =>
    s.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const startRename = (s: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(s.id);
    setEditTitle(s.title);
  };

  const saveRename = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  const cancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(null);
  };

  return (
    <>
      {/* Mobile Backdrop overlay */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 bg-black/70 backdrop-blur-xs z-40 md:hidden"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed md:static inset-y-0 left-0 z-40 w-72 md:w-64 lg:w-72 bg-gray-950/95 md:bg-gray-950/60 border-r border-cyan-500/20 backdrop-blur-md flex flex-col transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Mobile Header inside drawer */}
        <div className="p-3 border-b border-cyan-500/20 flex md:hidden items-center justify-between">
          <span className="font-orbitron font-bold text-cyan-300 text-sm">
            SYSTEM ARCHIVES
          </span>
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-cyan-300 rounded-lg hover:bg-cyan-950/50"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile Tab Navigation */}
        <div className="p-3 border-b border-cyan-500/15 md:hidden flex flex-col gap-1">
          <button
            onClick={() => {
              setActiveTab('dashboard');
              onClose();
            }}
            className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-orbitron transition-all ${
              activeTab === 'dashboard'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-gray-400 hover:text-cyan-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>DASHBOARD HUD</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('chat');
              onClose();
            }}
            className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-orbitron transition-all ${
              activeTab === 'chat'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-gray-400 hover:text-cyan-200'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>NEURAL CHAT</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('protocols');
              onClose();
            }}
            className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-orbitron transition-all ${
              activeTab === 'protocols'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                : 'text-gray-400 hover:text-cyan-200'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>TACTICAL PROTOCOLS</span>
          </button>
        </div>

        {/* New Session Action */}
        <div className="p-3">
          <button
            onClick={() => {
              onNewSession();
              setActiveTab('chat');
              if (window.innerWidth < 768) onClose();
            }}
            className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 hover:border-cyan-400 text-cyan-300 font-orbitron text-xs tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.15)] group"
          >
            <Plus className="w-4 h-4 transition-transform group-hover:rotate-90 duration-200" />
            <span>NEW PROTOCOL SESSION</span>
          </button>
        </div>

        {/* Search Chat Archives */}
        <div className="px-3 pb-2">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-cyan-500/60 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search logs & chats..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/60 border border-cyan-500/20 rounded-md pl-8 pr-2 py-1.5 text-xs text-cyan-100 placeholder:text-gray-500 focus:outline-hidden focus:border-cyan-400 font-mono"
            />
          </div>
        </div>

        {/* Sessions History List */}
        <div className="flex-1 overflow-y-auto px-2 space-y-1">
          <div className="px-2 pt-2 pb-1 text-[10px] font-mono tracking-wider text-cyan-400/60 flex items-center justify-between">
            <span>STORED ENGAGEMENTS ({filteredSessions.length})</span>
          </div>

          {filteredSessions.length === 0 ? (
            <div className="p-4 text-center text-xs text-gray-500 font-mono">
              No matching archive logs found.
            </div>
          ) : (
            filteredSessions.map((session) => {
              const isActive = session.id === activeSessionId;
              const isEditing = session.id === editingId;

              return (
                <div
                  key={session.id}
                  onClick={() => {
                    onSelectSession(session.id);
                    setActiveTab('chat');
                    if (window.innerWidth < 768) onClose();
                  }}
                  className={`group relative flex items-center justify-between px-2.5 py-2 rounded-lg text-xs transition-all cursor-pointer border ${
                    isActive
                      ? 'bg-cyan-950/70 border-cyan-400/60 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                      : 'border-transparent text-gray-400 hover:text-cyan-200 hover:bg-slate-900/50 hover:border-cyan-500/20'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <MessageSquare
                      className={`w-3.5 h-3.5 shrink-0 ${
                        isActive ? 'text-cyan-400' : 'text-gray-500 group-hover:text-cyan-400'
                      }`}
                    />

                    {isEditing ? (
                      <input
                        type="text"
                        autoFocus
                        value={editTitle}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') saveRename(session.id, e as any);
                          if (e.key === 'Escape') cancelRename(e as any);
                        }}
                        className="w-full bg-black/80 border border-cyan-400 rounded px-1.5 py-0.5 text-xs text-cyan-200 focus:outline-hidden"
                      />
                    ) : (
                      <span className="truncate font-rajdhani font-medium tracking-wide">
                        {session.title || 'Untitled Protocol'}
                      </span>
                    )}
                  </div>

                  {/* Actions (Rename, Delete) */}
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    {isEditing ? (
                      <>
                        <button
                          onClick={(e) => saveRename(session.id, e)}
                          title="Save"
                          className="p-1 text-emerald-400 hover:text-emerald-300"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={cancelRename}
                          title="Cancel"
                          className="p-1 text-gray-400 hover:text-gray-200"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          onClick={(e) => startRename(session, e)}
                          title="Rename log"
                          className="p-1 text-gray-400 hover:text-cyan-300"
                        >
                          <Edit2 className="w-3 h-3" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeleteSession(session.id);
                          }}
                          title="Purge session"
                          className="p-1 text-gray-400 hover:text-rose-400"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Sidebar Footer */}
        <div className="p-3 border-t border-cyan-500/20 bg-gray-950/80 flex flex-col gap-2">
          {/* User info mini-card */}
          <div className="flex items-center gap-2.5 px-2 py-1.5 rounded-lg bg-cyan-950/30 border border-cyan-500/20 text-xs">
            <Shield className="w-4 h-4 text-cyan-400 shrink-0" />
            <div className="flex-1 truncate">
              <div className="text-cyan-200 font-rajdhani font-semibold truncate">
                {user?.name || 'Chief Engineer'}
              </div>
              <div className="text-[10px] text-cyan-500/70 font-mono">
                {user?.clearanceLevel || 'LEVEL 7 AUTH'}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => {
                onOpenSettings();
                if (window.innerWidth < 768) onClose();
              }}
              className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-2 rounded-md border border-cyan-500/20 hover:border-cyan-400/50 hover:bg-cyan-950/40 text-xs text-cyan-300 font-mono transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>SETTINGS</span>
            </button>
            <button
              onClick={() => {
                onOpenSetup();
                if (window.innerWidth < 768) onClose();
              }}
              className="p-1.5 rounded-md border border-cyan-500/20 hover:border-cyan-400/50 hover:bg-cyan-950/40 text-cyan-400 transition-colors"
              title="System Diagnostics & Guide"
            >
              <HelpCircle className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
