import React, { useState, useEffect } from 'react';
import {
  X,
  Sliders,
  Volume2,
  Bot,
  User,
  Languages,
  Check,
  RotateCcw,
  Sparkles,
  Play,
  Layers,
} from 'lucide-react';
import { GeminiVoice, JarvisSettings, LanguageMode, PersonalityMode } from '../types';
import { voiceOutput, soundEffects } from '../services/speech';
import { requestNeuralTTS } from '../services/api';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: JarvisSettings;
  onSave: (newSettings: JarvisSettings) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [formData, setFormData] = useState<JarvisSettings>(settings);
  const [browserVoices, setBrowserVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [isPlayingTest, setIsPlayingTest] = useState(false);

  useEffect(() => {
    setFormData(settings);
  }, [settings, isOpen]);

  // Load browser TTS voices
  useEffect(() => {
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      const loadVoices = () => {
        const voices = window.speechSynthesis.getVoices();
        setBrowserVoices(voices);
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  if (!isOpen) return null;

  const geminiVoices: { name: GeminiVoice; desc: string; vibe: string }[] = [
    { name: 'Fenrir', desc: 'Deep, poised British-style butler tone (Default JARVIS)', vibe: 'Iconic Stark AI' },
    { name: 'Zephyr', desc: 'Crisp, modern, and agile tech tone', vibe: 'Sleek Cyber' },
    { name: 'Kore', desc: 'Calm, articulate, and poised female persona (FRIDAY style)', vibe: 'FRIDAY / Warm' },
    { name: 'Puck', desc: 'Energetic, witty, and lively companion', vibe: 'Playful & Fast' },
    { name: 'Charon', desc: 'Commanding, authoritative, deep military cadence', vibe: 'Tactical Command' },
  ];

  const handleTestVoice = async () => {
    soundEffects.playHudChime();
    setIsPlayingTest(true);

    const testPhrase =
      formData.defaultLanguage === 'hindi'
        ? `नमस्ते ${formData.userTitle}, मैं ${formData.assistantName} हूँ। सभी प्रणालियाँ कार्यरत हैं।`
        : formData.defaultLanguage === 'hinglish'
        ? `Main ${formData.assistantName} hoon, ${formData.userTitle}. Sabhi systems green hain, ready for action!`
        : `At your service, ${formData.userTitle}. I am ${formData.assistantName}, fully operational and awaiting your command.`;

    try {
      if (formData.useGeminiTTS) {
        const res = await requestNeuralTTS(testPhrase, formData.ttsVoice);
        if (!res.fallbackToBrowser && res.audioData) {
          await voiceOutput.playWavBase64(res.audioData, res.mimeType);
          setIsPlayingTest(false);
          return;
        }
      }

      await voiceOutput.speakBrowser(testPhrase, {
        voiceUri: formData.browserVoiceUri,
        rate: formData.speechRate,
        pitch: formData.speechPitch,
      });
    } catch {
      // ignore
    } finally {
      setIsPlayingTest(false);
    }
  };

  const handleSave = () => {
    soundEffects.playHudChime();
    onSave(formData);
    onClose();
  };

  const handleReset = () => {
    setFormData({
      assistantName: 'J.A.R.V.I.S.',
      userName: 'Tony Stark',
      userTitle: 'Sir',
      personality: 'jarvis',
      defaultLanguage: 'auto',
      ttsVoice: 'Fenrir',
      useGeminiTTS: true,
      autoSpeak: true,
      speechRate: 1.0,
      speechPitch: 1.0,
      soundEffects: true,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-2xl max-h-[90vh] bg-gray-950 border border-cyan-500/30 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-cyan-500/20 bg-gray-900/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Sliders className="w-5 h-5 text-cyan-400" />
            <h2 className="font-orbitron font-bold text-base md:text-lg text-cyan-100 tracking-wider">
              CORE SYSTEM CONFIGURATION
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
          {/* Section: Identity Customization */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-orbitron font-bold text-cyan-400 tracking-wider">
              <Bot className="w-4 h-4 text-cyan-400" />
              <span>AI ASSISTANT IDENTITY</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-mono text-cyan-300/80 mb-1">
                  Assistant Call-Sign / Name
                </label>
                <input
                  type="text"
                  value={formData.assistantName}
                  onChange={(e) => setFormData({ ...formData, assistantName: e.target.value })}
                  placeholder="e.g. J.A.R.V.I.S., F.R.I.D.A.Y."
                  className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-3 py-2 text-sm text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-xs font-mono text-cyan-300/80 mb-1">
                  How AI Addresses You (User Title)
                </label>
                <input
                  type="text"
                  value={formData.userTitle}
                  onChange={(e) => setFormData({ ...formData, userTitle: e.target.value })}
                  placeholder="e.g. Sir, Boss, Tony, Commander"
                  className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-3 py-2 text-sm text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Quick Name Presets */}
            <div className="flex items-center gap-2 pt-1">
              <span className="text-[10px] font-mono text-cyan-500/60">PRESETS:</span>
              {['J.A.R.V.I.S.', 'F.R.I.D.A.Y.', 'E.D.I.T.H.', 'AURA'].map((preset) => (
                <button
                  key={preset}
                  type="button"
                  onClick={() => setFormData({ ...formData, assistantName: preset })}
                  className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-950/50 border border-cyan-500/20 hover:border-cyan-400 text-cyan-300"
                >
                  {preset}
                </button>
              ))}
            </div>
          </div>

          {/* Section: Personality Mode */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-orbitron font-bold text-cyan-400 tracking-wider">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>NEURAL PERSONALITY MODE</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {[
                {
                  id: 'jarvis',
                  name: "Tony's JARVIS",
                  desc: 'Sophisticated, witty, extraordinarily capable, classic Stark demeanor.',
                },
                {
                  id: 'tech_butler',
                  name: 'Tactical Butler',
                  desc: 'Hyper-formal, strictly analytical, direct and ultra-concise.',
                },
                {
                  id: 'companion',
                  name: 'Friendly Co-Pilot',
                  desc: 'Warm, conversational, bilingual buddy with enthusiasm.',
                },
              ].map((p) => (
                <div
                  key={p.id}
                  onClick={() =>
                    setFormData({ ...formData, personality: p.id as PersonalityMode })
                  }
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${
                    formData.personality === p.id
                      ? 'bg-cyan-950/70 border-cyan-400 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : 'bg-slate-900/40 border-cyan-500/15 text-gray-400 hover:text-cyan-200 hover:border-cyan-500/30'
                  }`}
                >
                  <div className="font-orbitron font-semibold text-xs text-cyan-200">
                    {p.name}
                  </div>
                  <div className="text-[11px] font-rajdhani text-cyan-400/70 mt-1 leading-tight">
                    {p.desc}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Voice & Speech Engine */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-orbitron font-bold text-cyan-400 tracking-wider">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>TEXT-TO-SPEECH (TTS) VOICES</span>
              </div>

              <button
                type="button"
                onClick={handleTestVoice}
                disabled={isPlayingTest}
                className="px-2.5 py-1 rounded-md bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-all active:scale-95 disabled:opacity-50"
              >
                <Play className="w-3 h-3 fill-cyan-400" />
                <span>{isPlayingTest ? 'PLAYING...' : 'SAMPLE VOICE'}</span>
              </button>
            </div>

            {/* Gemini Neural TTS selector */}
            <div className="p-3.5 rounded-xl bg-gray-900/70 border border-cyan-500/25 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-mono text-xs text-cyan-200 font-bold">
                    Gemini 3.8 Flash Neural Voice
                  </div>
                  <div className="text-[11px] text-cyan-500/70 font-rajdhani">
                    High-fidelity neural synthesis directly from Google Gemini 3.8
                  </div>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.useGeminiTTS}
                    onChange={(e) =>
                      setFormData({ ...formData, useGeminiTTS: e.target.checked })
                    }
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-gray-700 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-cyan-300 after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-cyan-600"></div>
                </label>
              </div>

              {formData.useGeminiTTS && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                  {geminiVoices.map((v) => (
                    <div
                      key={v.name}
                      onClick={() => setFormData({ ...formData, ttsVoice: v.name })}
                      className={`p-2.5 rounded-lg border cursor-pointer transition-all ${
                        formData.ttsVoice === v.name
                          ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                          : 'bg-slate-900/50 border-cyan-500/15 text-gray-400 hover:text-cyan-200'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-orbitron text-xs font-bold text-cyan-200">
                          {v.name}
                        </span>
                        <span className="text-[9px] font-mono text-cyan-400/80 px-1.5 py-0.5 rounded bg-cyan-950 border border-cyan-500/30">
                          {v.vibe}
                        </span>
                      </div>
                      <p className="text-[11px] font-rajdhani text-cyan-400/70 mt-1">
                        {v.desc}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Fallback Browser Voices (if user wants native browser voice) */}
            <div>
              <label className="block text-xs font-mono text-cyan-300/80 mb-1">
                Local Device Voice Engine (Backup)
              </label>
              <select
                value={formData.browserVoiceUri || ''}
                onChange={(e) => setFormData({ ...formData, browserVoiceUri: e.target.value })}
                className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-3 py-2 text-xs text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
              >
                <option value="">Default System Voice (Auto-detect)</option>
                {browserVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>

            {/* Voice Sliders (Rate & Pitch) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
              <div>
                <div className="flex justify-between text-xs font-mono text-cyan-300/80 mb-1">
                  <span>Speech Cadence (Rate)</span>
                  <span className="text-cyan-400 font-bold">{formData.speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.7"
                  max="1.4"
                  step="0.05"
                  value={formData.speechRate}
                  onChange={(e) =>
                    setFormData({ ...formData, speechRate: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>

              <div>
                <div className="flex justify-between text-xs font-mono text-cyan-300/80 mb-1">
                  <span>Voice Pitch</span>
                  <span className="text-cyan-400 font-bold">{formData.speechPitch}x</span>
                </div>
                <input
                  type="range"
                  min="0.8"
                  max="1.3"
                  step="0.05"
                  value={formData.speechPitch}
                  onChange={(e) =>
                    setFormData({ ...formData, speechPitch: parseFloat(e.target.value) })
                  }
                  className="w-full accent-cyan-400"
                />
              </div>
            </div>

            {/* Auto Speak Toggle */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-slate-900/40 border border-cyan-500/15">
              <div>
                <div className="text-xs font-mono text-cyan-200 font-semibold">
                  Auto-Speak Incoming Answers
                </div>
                <div className="text-[11px] text-cyan-500/70 font-rajdhani">
                  Assistant automatically voices responses aloud upon receipt.
                </div>
              </div>
              <input
                type="checkbox"
                checked={formData.autoSpeak}
                onChange={(e) => setFormData({ ...formData, autoSpeak: e.target.checked })}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className="p-4 border-t border-cyan-500/20 bg-gray-900/60 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-cyan-500/20 hover:border-cyan-400 text-xs font-mono text-gray-400 hover:text-cyan-300 transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET DEFAULTS</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg border border-gray-700 hover:border-gray-500 text-xs font-orbitron text-gray-300 transition-colors"
            >
              CANCEL
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-orbitron font-bold text-xs tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.4)] active:scale-95 flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              <span>APPLY SETTINGS</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
