import React, { useState } from 'react';
import {
  X,
  Shield,
  Key,
  UserCheck,
  Check,
  UserPlus,
  LogIn,
  Fingerprint,
} from 'lucide-react';
import { UserProfile } from '../types';
import { soundEffects } from '../services/speech';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile | null;
  onLogin: (user: UserProfile) => void;
  onLogout: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogin,
  onLogout,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('Chief Engineer');
  const [clearance, setClearance] = useState<UserProfile['clearanceLevel']>('LEVEL 7');

  if (!isOpen) return null;

  const defaultProfiles: UserProfile[] = [
    {
      id: 'stark-alpha',
      name: 'Tony Stark',
      email: 'tony@starkindustries.com',
      role: 'CEO & Founder',
      clearanceLevel: 'ALPHA - STARK',
      joinedAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
    },
    {
      id: 'yuvraj-lead',
      name: 'Yuvraj Maurya',
      email: 'yuvrajmaurya370@gmail.com',
      role: 'Chief AI Architect',
      clearanceLevel: 'LEVEL 7',
      joinedAt: Date.now() - 1000 * 60 * 60 * 24 * 7,
    },
    {
      id: 'banner-research',
      name: 'Dr. Bruce Banner',
      email: 'banner@avengers.org',
      role: 'Gamma & Quantum Specialist',
      clearanceLevel: 'LEVEL 7',
      joinedAt: Date.now() - 1000 * 60 * 60 * 24 * 14,
    },
    {
      id: 'guest-observer',
      name: 'Field Operative',
      email: 'guest@shield.gov',
      role: 'Guest Analyst',
      clearanceLevel: 'LEVEL 1',
      joinedAt: Date.now(),
    },
  ];

  const handleSelectPreset = (profile: UserProfile) => {
    soundEffects.playHudChime();
    onLogin(profile);
    onClose();
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    soundEffects.playHudChime();
    const newUser: UserProfile = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      email: email.trim() || `${name.toLowerCase().replace(/\s+/g, '')}@stark.local`,
      role: role.trim() || 'Tactical Operator',
      clearanceLevel: clearance,
      joinedAt: Date.now(),
    };

    onLogin(newUser);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-gray-950 border border-cyan-500/40 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.3)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-cyan-500/20 bg-gray-900/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Fingerprint className="w-5 h-5 text-cyan-400" />
            <h2 className="font-orbitron font-bold text-base text-cyan-100 tracking-wider">
              STARK CLEARANCE AUTHENTICATION
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 md:p-6 space-y-5 overflow-y-auto max-h-[80vh]">
          {/* Current Active Status */}
          {currentUser && (
            <div className="p-3.5 rounded-xl bg-cyan-950/60 border border-cyan-400/50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-600 to-blue-500 flex items-center justify-center font-orbitron font-bold text-black text-sm">
                  {currentUser.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="font-orbitron text-sm font-bold text-cyan-100">
                    {currentUser.name}
                  </div>
                  <div className="text-[11px] font-mono text-cyan-400">
                    {currentUser.role} • {currentUser.clearanceLevel}
                  </div>
                </div>
              </div>

              <button
                onClick={() => {
                  soundEffects.playHudChime();
                  onLogout();
                }}
                className="px-3 py-1.5 rounded-lg border border-rose-500/40 text-rose-300 hover:bg-rose-950/40 text-xs font-mono transition-colors"
              >
                DISCONNECT
              </button>
            </div>
          )}

          {/* Quick Clearance Profiles */}
          <div className="space-y-2">
            <label className="block text-xs font-mono text-cyan-400/80 font-bold uppercase">
              Quick Authorization Profiles (Instant Switch)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {defaultProfiles.map((p) => {
                const isCurrent = currentUser?.id === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => handleSelectPreset(p)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      isCurrent
                        ? 'bg-cyan-950/80 border-cyan-400 text-cyan-200 ring-1 ring-cyan-400'
                        : 'bg-slate-900/50 border-cyan-500/20 text-gray-400 hover:text-cyan-200 hover:border-cyan-400/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-orbitron text-xs font-bold text-cyan-200">
                        {p.name}
                      </span>
                      {isCurrent && <Check className="w-3.5 h-3.5 text-emerald-400" />}
                    </div>
                    <div className="text-[11px] font-rajdhani text-cyan-400/70 mt-0.5">
                      {p.role}
                    </div>
                    <div className="text-[9px] font-mono text-cyan-500/80 mt-1">
                      [{p.clearanceLevel}]
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Custom Identity Entry Form */}
          <form onSubmit={handleCustomSubmit} className="space-y-3 pt-2 border-t border-cyan-500/20">
            <span className="block text-xs font-mono text-cyan-400/80 font-bold uppercase">
              Or Authenticate Custom Operative
            </span>

            <div className="space-y-2">
              <div>
                <label className="block text-[11px] font-mono text-cyan-300/80 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Peter Parker"
                  className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-xs text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-mono text-cyan-300/80 mb-1">
                    Role / Title
                  </label>
                  <input
                    type="text"
                    value={role}
                    onChange={(e) => setRole(e.target.value)}
                    placeholder="e.g. Systems Engineer"
                    className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-3 py-1.5 text-xs text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-mono text-cyan-300/80 mb-1">
                    Clearance Tier
                  </label>
                  <select
                    value={clearance}
                    onChange={(e) => setClearance(e.target.value as any)}
                    className="w-full bg-slate-900/80 border border-cyan-500/30 rounded-lg px-2 py-1.5 text-xs text-cyan-100 font-mono focus:border-cyan-400 focus:outline-hidden"
                  >
                    <option value="ALPHA - STARK">ALPHA - STARK</option>
                    <option value="LEVEL 7">LEVEL 7</option>
                    <option value="LEVEL 4">LEVEL 4</option>
                    <option value="LEVEL 1">LEVEL 1</option>
                  </select>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="w-full mt-2 py-2 px-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-orbitron font-bold text-xs tracking-wider transition-all shadow-[0_0_12px_rgba(6,182,212,0.4)] active:scale-95 flex items-center justify-center gap-2"
            >
              <LogIn className="w-4 h-4" />
              <span>AUTHENTICATE & LOG IN</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
