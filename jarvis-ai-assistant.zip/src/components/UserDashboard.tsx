import React, { useState, useEffect } from 'react';
import {
  Shield,
  Cpu,
  Zap,
  Activity,
  Battery,
  Wifi,
  Sparkles,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  Terminal,
  MessageSquare,
  Globe,
  Flame,
} from 'lucide-react';
import { JarvisSettings, SystemTelemetry, UserProfile } from '../types';
import { ArcReactorCore } from './ArcReactorCore';
import { soundEffects } from '../services/speech';

interface UserDashboardProps {
  user: UserProfile | null;
  settings: JarvisSettings;
  telemetry: SystemTelemetry;
  totalMessagesCount: number;
  totalSessionsCount: number;
  onExecuteProtocol: (prompt: string) => void;
  onOpenSettings: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  user,
  settings,
  telemetry,
  totalMessagesCount,
  totalSessionsCount,
  onExecuteProtocol,
  onOpenSettings,
}) => {
  const [coreStatus, setCoreStatus] = useState<'idle' | 'listening' | 'thinking' | 'speaking'>('idle');
  const [activeDiagnostic, setActiveDiagnostic] = useState<string | null>(null);

  const runDiagnostic = (name: string, prompt: string) => {
    soundEffects.playHudChime();
    setActiveDiagnostic(name);
    setCoreStatus('thinking');

    setTimeout(() => {
      setCoreStatus('idle');
      setActiveDiagnostic(null);
      onExecuteProtocol(prompt);
    }, 1200);
  };

  const protocols = [
    {
      id: 'diagnostic',
      name: 'Full Armor & Core Diagnostics',
      desc: 'Deep hardware analysis of all subsystems, power grids, and propulsion.',
      prompt: 'JARVIS, run a full system diagnostics scan and report back subsystem integrity in your classic Tony Stark tone.',
      icon: Activity,
      tag: 'SECURITY',
    },
    {
      id: 'weather',
      name: 'Atmospheric & Weather Radar',
      desc: 'Scan current weather conditions, satellite feeds, and forecast in Hinglish.',
      prompt: 'JARVIS, mujhe aaj ka weather forecast aur atmospheric analysis Hinglish mein batao.',
      icon: Globe,
      tag: 'METEOROLOGY',
    },
    {
      id: 'hindi_drill',
      name: 'हिन्दी संवाद प्रोटोकॉल (Hindi Protocol)',
      desc: 'Execute interactive conversational briefing entirely in polite Devanagari Hindi.',
      prompt: 'जार्विस, नमस्ते! आज के कार्यों की विस्तृत सूची और प्राथमिकताएं हिन्दी में समझाइए।',
      icon: Sparkles,
      tag: 'LANGUAGE',
    },
    {
      id: 'tech_advisor',
      name: 'Quantum & AI Architecture Advisor',
      desc: 'Architectural breakdown and strategic advice on modern tech stacks.',
      prompt: 'JARVIS, as chief technical advisor, explain the architecture of modern AI neural agents with code recommendations.',
      icon: Cpu,
      tag: 'ENGINEERING',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 bg-cyber-grid">
      {/* Top Banner: Greeting & Arc Reactor Centerpiece */}
      <div className="relative rounded-2xl bg-gradient-to-r from-gray-950 via-slate-900 to-cyan-950/80 border border-cyan-500/30 p-6 md:p-8 overflow-hidden shadow-[0_0_30px_rgba(6,182,212,0.15)]">
        {/* Glow corner ornaments */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-3 text-center md:text-left max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-400/40 text-cyan-300 text-xs font-mono tracking-wider">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>CLEARANCE: {user?.clearanceLevel || 'LEVEL 7 - STARK'}</span>
            </div>

            <h1 className="text-2xl md:text-4xl font-extrabold font-orbitron text-cyan-50 tracking-wide glow-text-cyan">
              WELCOME BACK, <span className="text-cyan-400">{user?.name || settings.userTitle}</span>
            </h1>

            <p className="text-sm md:text-base font-rajdhani text-cyan-200/80 leading-relaxed">
              {settings.assistantName} Mark VI online and synced with the local terminal. All core neural
              pathways are operational. Multilingual protocol (English / Hinglish / Hindi) ready for your voice
              or keyboard commands.
            </p>

            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3 pt-2">
              <button
                onClick={() =>
                  runDiagnostic(
                    'Full Armor & Core Diagnostics',
                    'JARVIS, run a full system diagnostics scan and report back subsystem integrity.'
                  )
                }
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-orbitron font-bold text-xs tracking-wider transition-all shadow-[0_0_15px_rgba(6,182,212,0.5)] active:scale-95 flex items-center gap-2"
              >
                <Play className="w-3.5 h-3.5 fill-black" />
                <span>INITIATE DIAGNOSTICS</span>
              </button>

              <button
                onClick={onOpenSettings}
                className="px-4 py-2 rounded-xl bg-cyan-950/60 hover:bg-cyan-900/60 border border-cyan-500/40 text-cyan-300 font-orbitron text-xs tracking-wider transition-all"
              >
                CONFIGURE CORE
              </button>
            </div>
          </div>

          {/* Interactive Arc Reactor Core */}
          <div className="flex flex-col items-center">
            <ArcReactorCore
              status={coreStatus}
              size="md"
              assistantName={settings.assistantName}
              onClick={() => soundEffects.playHudChime()}
            />
            <span className="text-[11px] font-mono text-cyan-400/70 mt-3 tracking-widest">
              ARC REACTOR CORE: 3.8 GW
            </span>
          </div>
        </div>
      </div>

      {/* Telemetry Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
        {/* Core Integrity */}
        <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/20 backdrop-blur-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-[11px] font-mono tracking-wider text-cyan-500/80">CORE INTEGRITY</span>
            <Shield className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="my-2 text-2xl font-orbitron font-bold text-cyan-200">
            {telemetry.coreIntegrity}%
          </div>
          <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-cyan-400 h-1.5 rounded-full shadow-[0_0_8px_rgba(6,182,212,1)]"
              style={{ width: `${telemetry.coreIntegrity}%` }}
            />
          </div>
        </div>

        {/* Neural Sync */}
        <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/20 backdrop-blur-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-[11px] font-mono tracking-wider text-cyan-500/80">NEURAL SYNC</span>
            <Cpu className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="my-2 text-2xl font-orbitron font-bold text-cyan-200">
            {telemetry.neuralSync}%
          </div>
          <div className="w-full bg-slate-900 rounded-full h-1.5 overflow-hidden">
            <div
              className="bg-emerald-400 h-1.5 rounded-full shadow-[0_0_8px_rgba(52,211,153,1)]"
              style={{ width: `${telemetry.neuralSync}%` }}
            />
          </div>
        </div>

        {/* Total Interactions */}
        <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/20 backdrop-blur-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-[11px] font-mono tracking-wider text-cyan-500/80">INTERACTIONS</span>
            <MessageSquare className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="my-2 text-2xl font-orbitron font-bold text-cyan-200">
            {totalMessagesCount}
          </div>
          <span className="text-[10px] font-mono text-cyan-500/60">
            Across {totalSessionsCount} session archive(s)
          </span>
        </div>

        {/* Battery / System Power */}
        <div className="p-4 rounded-xl bg-gray-950/80 border border-cyan-500/20 backdrop-blur-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-[11px] font-mono tracking-wider text-cyan-500/80">POWER RESERVE</span>
            <Battery className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="my-2 text-2xl font-orbitron font-bold text-cyan-200">
            {telemetry.batteryLevel !== null ? `${Math.round(telemetry.batteryLevel * 100)}%` : '100% (STARK GRID)'}
          </div>
          <span className="text-[10px] font-mono text-cyan-500/60">
            {telemetry.isCharging ? 'ARC RECHARGING' : 'NOMINAL BATTERY'}
          </span>
        </div>
      </div>

      {/* Quick Tactical Protocols Section */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Terminal className="w-5 h-5 text-cyan-400" />
            <h2 className="font-orbitron font-bold text-base md:text-lg text-cyan-200 tracking-wider">
              TACTICAL PROTOCOLS & COMMANDS
            </h2>
          </div>
          <span className="text-xs font-mono text-cyan-500/70">
            READY TO DEPLOY
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
          {protocols.map((proto) => {
            const Icon = proto.icon;
            const isRunning = activeDiagnostic === proto.name;

            return (
              <div
                key={proto.id}
                className="group p-4 rounded-xl bg-gray-950/70 border border-cyan-500/25 hover:border-cyan-400/70 hover:bg-slate-900/60 transition-all cursor-pointer flex flex-col justify-between gap-3 shadow-[0_4px_15px_rgba(0,0,0,0.3)] hover:shadow-[0_0_20px_rgba(6,182,212,0.2)]"
                onClick={() => runDiagnostic(proto.name, proto.prompt)}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg bg-cyan-950/70 border border-cyan-500/40 text-cyan-300 group-hover:text-cyan-200 group-hover:border-cyan-300 transition-colors">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-orbitron font-semibold text-sm text-cyan-100 group-hover:text-cyan-300 transition-colors">
                        {proto.name}
                      </h3>
                      <span className="text-[10px] font-mono text-cyan-500/70 tracking-wider uppercase">
                        [{proto.tag}]
                      </span>
                    </div>
                  </div>

                  <span className="text-xs text-cyan-400 group-hover:translate-x-1 transition-transform">
                    {isRunning ? (
                      <RotateCcw className="w-4 h-4 animate-spin text-cyan-300" />
                    ) : (
                      'EXECUTE →'
                    )}
                  </span>
                </div>

                <p className="text-xs text-cyan-300/70 font-rajdhani leading-relaxed">
                  {proto.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* System Telemetry & Hardware Log Feed */}
      <div className="rounded-xl bg-gray-950/90 border border-cyan-500/25 p-4 md:p-5 font-mono text-xs">
        <div className="flex items-center justify-between pb-2 mb-3 border-b border-cyan-500/20 text-cyan-400">
          <span className="font-bold flex items-center gap-1.5">
            <Activity className="w-4 h-4" />
            <span>JARVIS SYSTEM EVENT TELEMETRY</span>
          </span>
          <span className="text-[10px] text-cyan-500/70">AUTO-REFRESH: 1000ms</span>
        </div>

        <div className="space-y-1.5 text-cyan-300/80 text-[11px]">
          <div className="flex items-center justify-between">
            <span>[SYS.INIT] J.A.R.V.I.S. Neural Core v4.8 loaded</span>
            <span className="text-emerald-400">NOMINAL</span>
          </div>
          <div className="flex items-center justify-between">
            <span>[SYS.NET] Satellite uplink to Gemini 3.8 Flash Engine</span>
            <span className="text-cyan-400">{telemetry.latencyMs}ms LATENCY</span>
          </div>
          <div className="flex items-center justify-between">
            <span>[SYS.AUDIO] Web Speech Recognition & Neural TTS Synthesizer</span>
            <span className="text-emerald-400">SYNCHRONIZED</span>
          </div>
          <div className="flex items-center justify-between">
            <span>[SYS.LANG] Multilingual Lexicon (Hinglish/Hindi/English)</span>
            <span className="text-emerald-400">LOADED (100%)</span>
          </div>
          <div className="flex items-center justify-between">
            <span>[SYS.AUTH] Stark Industries Clearance Authentication</span>
            <span className="text-cyan-400">{user?.clearanceLevel || 'LEVEL 7'}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
