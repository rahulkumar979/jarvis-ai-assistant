import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Cpu,
  Lock,
  CheckCircle,
  HelpCircle,
  AlertTriangle,
  RotateCw,
  Server,
  Terminal,
} from 'lucide-react';
import { checkServerHealth, HealthResponse } from '../services/api';
import { soundEffects } from '../services/speech';

interface SetupInfoModalProps {
  isOpen: boolean;
  onClose: () => void;
  hasGeminiKey: boolean;
}

export const SetupInfoModal: React.FC<SetupInfoModalProps> = ({
  isOpen,
  onClose,
  hasGeminiKey,
}) => {
  const [testingHealth, setTestingHealth] = useState(false);
  const [healthResult, setHealthResult] = useState<HealthResponse | null>(null);

  if (!isOpen) return null;

  const handleRunDiagnostics = async () => {
    soundEffects.playHudChime();
    setTestingHealth(true);
    try {
      const data = await checkServerHealth();
      setHealthResult(data);
    } catch {
      // ignore
    } finally {
      setTestingHealth(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 md:p-6 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-xl bg-gray-950 border border-cyan-500/30 rounded-2xl shadow-[0_0_50px_rgba(6,182,212,0.25)] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 md:p-5 border-b border-cyan-500/20 bg-gray-900/70 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Cpu className="w-5 h-5 text-cyan-400" />
            <h2 className="font-orbitron font-bold text-base text-cyan-100 tracking-wider">
              SYSTEM ARCHITECTURE & SETUP GUIDE
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-gray-400 hover:text-cyan-300 hover:bg-cyan-950/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 md:p-6 space-y-5 overflow-y-auto max-h-[80vh]">
          {/* Status Box */}
          <div
            className={`p-4 rounded-xl border flex items-start gap-3.5 ${
              hasGeminiKey
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                : 'bg-cyan-950/40 border-cyan-500/30 text-cyan-200'
            }`}
          >
            {hasGeminiKey ? (
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            )}
            <div className="space-y-1">
              <div className="font-orbitron font-bold text-sm tracking-wide">
                {hasGeminiKey
                  ? 'GEMINI FLASH NEURAL LINK ACTIVE'
                  : 'CONFIGURATION REQUIRED: GEMINI_API_KEY MISSING'}
              </div>
              <p className="text-xs font-rajdhani leading-relaxed text-cyan-300/80">
                {hasGeminiKey
                  ? 'JARVIS is connected to Google Gemini Flash (gemini-3.1-flash-lite) for high-speed free-tier neural reasoning, with gemini-3.8-flash-lite-tts for voice synthesis.'
                  : 'JARVIS requires a GEMINI_API_KEY environment variable. In AI Studio, ensure your API key is attached in Settings > Secrets. No paid tier or credit card is required.'}
              </p>
            </div>
          </div>

          {/* Architecture & Zero-Exposure Security */}
          <div className="space-y-2">
            <h3 className="font-orbitron text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Lock className="w-4 h-4 text-cyan-400" />
              <span>Full-Stack Security Architecture</span>
            </h3>
            <p className="text-xs font-rajdhani text-cyan-300/80 leading-relaxed">
              In adherence to enterprise security standards, API keys are <strong>never</strong> included
              in browser client bundles or accessible via frontend inspect tools. All AI inference is
              proxied through the server endpoint:
            </p>
            <div className="p-3 rounded-lg bg-black/70 border border-cyan-500/20 font-mono text-[11px] text-cyan-400 space-y-1">
              <div>[Client / Mobile Browser]</div>
              <div className="text-cyan-600">  │ (POST /api/chat & /api/tts)</div>
              <div>[Express Full-Stack Server] ← process.env.GEMINI_API_KEY</div>
              <div className="text-cyan-600">  │ (Encrypted Google GenAI SDK Proxy)</div>
              <div>[Google Gemini 3.8 Flash & Lite TTS Engines]</div>
            </div>
          </div>

          {/* How to enable live key */}
          <div className="space-y-2">
            <h3 className="font-orbitron text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              <span>Attaching Gemini API Key</span>
            </h3>
            <p className="text-xs font-rajdhani text-cyan-300/80 leading-relaxed">
              Your Google AI Studio environment automatically injects your free-tier eligible API key via
              the <strong>Settings &gt; Secrets</strong> panel as <code className="text-cyan-300 bg-cyan-950 px-1 py-0.5 rounded">GEMINI_API_KEY</code>.
              No manual configuration or credit card is required to preview or operate this application.
            </p>
          </div>

          {/* Live Ping Health Check */}
          <div className="p-3.5 rounded-xl bg-slate-900/60 border border-cyan-500/20 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-cyan-200">
                SYSTEM HEALTH DIAGNOSTIC
              </span>
              <button
                onClick={handleRunDiagnostics}
                disabled={testingHealth}
                className="px-3 py-1 rounded-md bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-all disabled:opacity-50"
              >
                <RotateCw className={`w-3.5 h-3.5 ${testingHealth ? 'animate-spin' : ''}`} />
                <span>{testingHealth ? 'TESTING...' : 'PING SERVER'}</span>
              </button>
            </div>

            {healthResult && (
              <div className="p-2.5 rounded bg-black/60 border border-cyan-500/30 font-mono text-[10px] text-cyan-300 space-y-1">
                <div>SYSTEM: {healthResult.system}</div>
                <div>STATUS: {healthResult.status}</div>
                <div>AI REASONING: {healthResult.model}</div>
                <div>VOICE SYNTHESIS: {healthResult.voiceSynthesizer}</div>
                <div>TIMESTAMP: {healthResult.timestamp}</div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-cyan-500/20 bg-gray-900/60 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-orbitron font-bold text-xs tracking-wider transition-all"
          >
            ACKNOWLEDGE
          </button>
        </div>
      </div>
    </div>
  );
};
