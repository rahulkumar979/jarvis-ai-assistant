import React from 'react';
import { Activity, Mic, Volume2 } from 'lucide-react';

interface ArcReactorCoreProps {
  status: 'idle' | 'listening' | 'thinking' | 'speaking';
  onClick?: () => void;
  size?: 'sm' | 'md' | 'lg';
  assistantName?: string;
}

export const ArcReactorCore: React.FC<ArcReactorCoreProps> = ({
  status,
  onClick,
  size = 'md',
  assistantName = 'J.A.R.V.I.S.',
}) => {
  const sizeClasses = {
    sm: 'w-24 h-24',
    md: 'w-44 h-44 md:w-52 md:h-52',
    lg: 'w-64 h-64 md:w-72 md:h-72',
  }[size];

  const coreGlow = {
    idle: 'from-cyan-500/20 via-blue-600/30 to-cyan-400/40 shadow-[0_0_30px_rgba(6,182,212,0.4)]',
    listening: 'from-amber-400/30 via-cyan-500/50 to-blue-600/60 shadow-[0_0_50px_rgba(34,211,238,0.7)] animate-pulse',
    thinking: 'from-blue-600/40 via-cyan-400/50 to-indigo-500/60 shadow-[0_0_45px_rgba(14,165,233,0.6)]',
    speaking: 'from-cyan-400/50 via-teal-400/60 to-blue-500/70 shadow-[0_0_60px_rgba(6,182,212,0.85)] animate-pulse',
  }[status];

  return (
    <div
      onClick={onClick}
      role="button"
      tabIndex={0}
      title={`${assistantName} Core - Status: ${status.toUpperCase()}`}
      className={`relative ${sizeClasses} flex items-center justify-center cursor-pointer select-none group transition-transform active:scale-95`}
    >
      {/* Ambient background glow ring */}
      <div
        className={`absolute inset-0 rounded-full bg-gradient-to-tr ${coreGlow} transition-all duration-700 blur-xl opacity-75`}
      />

      {/* Outermost Segmented HUD Ring */}
      <div className="absolute inset-1 rounded-full border border-cyan-500/30 border-dashed animate-hud-spin pointer-events-none" />

      {/* Counter-rotating Target Ring */}
      <div className="absolute inset-3 rounded-full border-2 border-transparent border-t-cyan-400/60 border-b-blue-500/60 animate-hud-spin-reverse pointer-events-none" />

      {/* Hexagonal / Segmented Tick Layer */}
      <div className="absolute inset-6 rounded-full border border-cyan-400/20 border-dotted pointer-events-none" />

      {/* Dynamic Activity Ring */}
      <div
        className={`absolute inset-8 rounded-full border-2 ${
          status === 'thinking'
            ? 'border-cyan-300 animate-hud-spin-fast'
            : status === 'listening'
            ? 'border-amber-400 border-dashed animate-hud-spin'
            : status === 'speaking'
            ? 'border-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.9)] animate-pulse'
            : 'border-cyan-500/40'
        } transition-colors duration-300`}
      />

      {/* Central Holographic Core */}
      <div className="relative w-24 h-24 md:w-28 md:h-28 rounded-full bg-gradient-to-b from-gray-950 via-slate-900 to-cyan-950 border-2 border-cyan-400/80 flex flex-col items-center justify-center p-2 shadow-[inset_0_0_20px_rgba(6,182,212,0.6)]">
        {/* Arc Reactor Inner Coils */}
        <div className="absolute inset-2 rounded-full border border-cyan-300/30 border-dashed animate-hud-spin" />

        {/* Center Dynamic Icon / Wave */}
        <div className="relative z-10 flex flex-col items-center justify-center">
          {status === 'listening' ? (
            <div className="flex flex-col items-center animate-bounce">
              <Mic className="w-6 h-6 text-amber-300 drop-shadow-[0_0_8px_rgba(251,191,36,0.8)]" />
              <span className="text-[9px] font-orbitron tracking-widest text-amber-300 font-bold mt-1">
                LISTENING
              </span>
            </div>
          ) : status === 'speaking' ? (
            <div className="flex flex-col items-center">
              <Volume2 className="w-6 h-6 text-cyan-300 drop-shadow-[0_0_10px_rgba(6,182,212,0.9)] animate-pulse" />
              {/* Dynamic waveform bars */}
              <div className="flex items-center gap-0.5 mt-1 h-3">
                <span className="w-1 bg-cyan-300 rounded-full animate-[pulse_0.4s_ease-in-out_infinite] h-2" />
                <span className="w-1 bg-cyan-200 rounded-full animate-[pulse_0.6s_ease-in-out_infinite] h-3" />
                <span className="w-1 bg-cyan-300 rounded-full animate-[pulse_0.3s_ease-in-out_infinite] h-2.5" />
                <span className="w-1 bg-cyan-100 rounded-full animate-[pulse_0.5s_ease-in-out_infinite] h-1.5" />
              </div>
            </div>
          ) : status === 'thinking' ? (
            <div className="flex flex-col items-center">
              <Activity className="w-6 h-6 text-cyan-300 animate-spin text-cyan-300 drop-shadow-[0_0_10px_rgba(6,182,212,0.9)]" />
              <span className="text-[9px] font-orbitron tracking-widest text-cyan-300 font-bold mt-1">
                PROCESSING
              </span>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <div className="w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,1)] animate-ping absolute opacity-60" />
              <div className="w-3.5 h-3.5 rounded-full bg-cyan-300 shadow-[0_0_10px_rgba(34,211,238,1)] relative z-10" />
              <span className="text-[9px] font-orbitron tracking-wider text-cyan-300/90 font-semibold mt-2">
                ACTIVE
              </span>
            </div>
          )}
        </div>

        {/* Small corner reticle indicators */}
        <div className="absolute top-1 left-1 w-1.5 h-1.5 border-t border-l border-cyan-400" />
        <div className="absolute top-1 right-1 w-1.5 h-1.5 border-t border-r border-cyan-400" />
        <div className="absolute bottom-1 left-1 w-1.5 h-1.5 border-b border-l border-cyan-400" />
        <div className="absolute bottom-1 right-1 w-1.5 h-1.5 border-b border-r border-cyan-400" />
      </div>
    </div>
  );
};
