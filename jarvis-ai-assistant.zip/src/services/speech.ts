// Web Speech API interfaces
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognitionErrorEvent extends Event {
  error: string;
  message?: string;
}

interface ISpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: ((this: ISpeechRecognition, ev: Event) => any) | null;
  onend: ((this: ISpeechRecognition, ev: Event) => any) | null;
  onerror: ((this: ISpeechRecognition, ev: SpeechRecognitionErrorEvent) => any) | null;
  onresult: ((this: ISpeechRecognition, ev: SpeechRecognitionEvent) => any) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: {
      new (): ISpeechRecognition;
    };
    webkitSpeechRecognition?: {
      new (): ISpeechRecognition;
    };
  }
}

// Sound effects synthesizer using Web Audio API
class SoundEffects {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  playHudChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(1760, ctx.currentTime + 0.12);
      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.15);
    } catch {
      // ignore
    }
  }

  playMicStart() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.frequency.setValueAtTime(660, ctx.currentTime + 0.08);
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.16);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // ignore
    }
  }

  playMicEnd() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(700, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(350, ctx.currentTime + 0.15);
      gain.gain.setValueAtTime(0.06, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.18);
    } catch {
      // ignore
    }
  }
}

export const soundEffects = new SoundEffects();

// Voice Recognition Wrapper
export class VoiceInputManager {
  private recognition: ISpeechRecognition | null = null;
  public isSupported: boolean = false;
  private onTranscriptCallback: ((text: string, isFinal: boolean) => void) | null = null;
  private onErrorCallback: ((error: string) => void) | null = null;
  private onEndCallback: (() => void) | null = null;
  public isListening: boolean = false;

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.isSupported = true;
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.setupHandlers();
      }
    }
  }

  private setupHandlers() {
    if (!this.recognition) return;

    this.recognition.onstart = () => {
      this.isListening = true;
    };

    this.recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interimTranscript = '';
      let finalTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }

      if (finalTranscript && this.onTranscriptCallback) {
        this.onTranscriptCallback(finalTranscript, true);
      } else if (interimTranscript && this.onTranscriptCallback) {
        this.onTranscriptCallback(interimTranscript, false);
      }
    };

    this.recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      this.isListening = false;
      let errorMsg = 'Voice recognition error';
      if (event.error === 'not-allowed') {
        errorMsg = 'Microphone permission was denied. Please allow microphone access.';
      } else if (event.error === 'no-speech') {
        errorMsg = 'No speech detected. Please speak closer to your microphone.';
      } else if (event.error === 'network') {
        errorMsg = 'Network connection issue for speech recognition.';
      } else {
        errorMsg = `Voice error: ${event.error}`;
      }
      if (this.onErrorCallback) {
        this.onErrorCallback(errorMsg);
      }
    };

    this.recognition.onend = () => {
      this.isListening = false;
      if (this.onEndCallback) {
        this.onEndCallback();
      }
    };
  }

  start(
    lang: string = 'en-IN',
    callbacks: {
      onTranscript: (text: string, isFinal: boolean) => void;
      onError: (err: string) => void;
      onEnd: () => void;
    }
  ) {
    if (!this.recognition) {
      callbacks.onError('Speech recognition is not supported on this browser. Chrome or Android Edge recommended.');
      return;
    }

    this.onTranscriptCallback = callbacks.onTranscript;
    this.onErrorCallback = callbacks.onError;
    this.onEndCallback = callbacks.onEnd;

    // Use appropriate language code
    // Hindi: 'hi-IN', English: 'en-IN' or 'en-US'
    this.recognition.lang = lang;

    try {
      this.recognition.start();
      soundEffects.playMicStart();
    } catch (err: any) {
      if (err.name !== 'InvalidStateError') {
        callbacks.onError(err.message || 'Could not start microphone');
      }
    }
  }

  stop() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
        soundEffects.playMicEnd();
      } catch {
        // ignore
      }
      this.isListening = false;
    }
  }
}

// Voice Output (TTS) Manager
export class VoiceOutputManager {
  private activeAudio: HTMLAudioElement | null = null;
  private activeUtterance: SpeechSynthesisUtterance | null = null;
  private keepAliveTimer: any = null;
  private isSpeakingState: boolean = false;
  private onStateChange: ((isSpeaking: boolean) => void) | null = null;

  public subscribe(cb: (isSpeaking: boolean) => void) {
    this.onStateChange = cb;
  }

  public get isSpeaking(): boolean {
    return this.isSpeakingState;
  }

  private setSpeaking(val: boolean) {
    this.isSpeakingState = val;
    if (this.onStateChange) {
      this.onStateChange(val);
    }
  }

  // Play base64 WAV audio from Gemini TTS
  playWavBase64(base64Data: string, mimeType: string = 'audio/wav'): Promise<void> {
    return new Promise((resolve, reject) => {
      this.stop();

      const audio = new Audio(`data:${mimeType};base64,${base64Data}`);
      this.activeAudio = audio;
      this.setSpeaking(true);

      audio.onended = () => {
        this.setSpeaking(false);
        this.activeAudio = null;
        resolve();
      };

      audio.onerror = () => {
        this.setSpeaking(false);
        this.activeAudio = null;
        reject(new Error('Audio playback failed'));
      };

      audio.play().catch((err) => {
        this.setSpeaking(false);
        this.activeAudio = null;
        reject(err);
      });
    });
  }

  // Free voice output using the browser SpeechSynthesis API
  speakBrowser(
    text: string,
    options: {
      lang?: string;
      voiceUri?: string;
      rate?: number;
      pitch?: number;
    } = {}
  ): Promise<void> {
    return new Promise((resolve) => {
      if (typeof window === 'undefined' || !window.speechSynthesis) {
        resolve();
        return;
      }

      this.stop();

      // Clean markdown tags, emojis, and code blocks for crisp speech synthesis
      const clean = text
        .replace(/```[\s\S]*?```/g, 'Code block omitted.')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/[*#_~]/g, '')
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/https?:\/\/\S+/g, '')
        .trim();

      if (!clean) {
        resolve();
        return;
      }

      const utterance = new SpeechSynthesisUtterance(clean);
      this.activeUtterance = utterance;

      utterance.rate = options.rate ?? 1.0;
      utterance.pitch = options.pitch ?? 1.0;

      // Detect language: Hindi Devanagari vs Hinglish vs English
      const isDevanagari = /[\u0900-\u097F]/.test(clean);
      const isHinglish =
        !isDevanagari &&
        /\b(kya|kaise|kaisa|theek|batao|karo|raha|rahi|hain|hoon|main|mera|meri|aaj|chalo|bilkul|shuru|karein|samjhao)\b/i.test(
          clean
        );

      let targetLang = options.lang || (isDevanagari ? 'hi-IN' : isHinglish ? 'en-IN' : 'en-US');
      if (isDevanagari) {
        targetLang = 'hi-IN';
      }
      utterance.lang = targetLang;

      // Select matching voice
      const voices = window.speechSynthesis.getVoices();
      if (options.voiceUri) {
        const found = voices.find((v) => v.voiceURI === options.voiceUri);
        if (found) utterance.voice = found;
      }

      if (!utterance.voice && voices.length > 0) {
        if (isDevanagari) {
          // Look for Hindi voice
          const hindiVoice =
            voices.find((v) => v.lang === 'hi-IN' || v.lang.startsWith('hi')) ||
            voices.find((v) => v.name.toLowerCase().includes('hindi'));
          if (hindiVoice) utterance.voice = hindiVoice;
        } else if (isHinglish) {
          // Look for Indian English voice (best for Hinglish pronunciation)
          const indianVoice =
            voices.find((v) => v.lang === 'en-IN' || v.lang.startsWith('en-IN')) ||
            voices.find(
              (v) =>
                v.name.toLowerCase().includes('india') ||
                v.name.toLowerCase().includes('hindi')
            ) ||
            voices.find((v) => v.lang.startsWith('en'));
          if (indianVoice) utterance.voice = indianVoice;
        } else {
          // Standard English voice
          const englishVoice =
            voices.find((v) => v.lang === targetLang) ||
            voices.find((v) => v.lang.startsWith('en-GB') || v.lang.startsWith('en-IN')) ||
            voices.find((v) => v.lang.startsWith('en'));
          if (englishVoice) utterance.voice = englishVoice;
        }
      }

      this.setSpeaking(true);

      // Chromium keep-alive timer for long speech synthesis
      if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = setInterval(() => {
        if (window.speechSynthesis.speaking) {
          window.speechSynthesis.pause();
          window.speechSynthesis.resume();
        } else {
          clearInterval(this.keepAliveTimer);
          this.keepAliveTimer = null;
        }
      }, 10000);

      utterance.onend = () => {
        if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
        this.keepAliveTimer = null;
        this.activeUtterance = null;
        this.setSpeaking(false);
        resolve();
      };

      utterance.onerror = () => {
        if (this.keepAliveTimer) clearInterval(this.keepAliveTimer);
        this.keepAliveTimer = null;
        this.activeUtterance = null;
        this.setSpeaking(false);
        resolve();
      };

      try {
        window.speechSynthesis.speak(utterance);
      } catch {
        this.setSpeaking(false);
        resolve();
      }
    });
  }

  stop() {
    if (this.keepAliveTimer) {
      clearInterval(this.keepAliveTimer);
      this.keepAliveTimer = null;
    }

    if (this.activeAudio) {
      try {
        this.activeAudio.pause();
        this.activeAudio.currentTime = 0;
      } catch {
        // ignore
      }
      this.activeAudio = null;
    }

    if (typeof window !== 'undefined' && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
      } catch {
        // ignore
      }
      this.activeUtterance = null;
    }

    this.setSpeaking(false);
  }
}

export const voiceOutput = new VoiceOutputManager();
export const voiceInput = new VoiceInputManager();
