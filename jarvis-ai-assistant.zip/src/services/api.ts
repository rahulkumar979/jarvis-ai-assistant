import { ChatMessage, GeminiVoice, LanguageMode, PersonalityMode } from '../types';

export interface HealthResponse {
  status: string;
  system: string;
  aiOnline: boolean;
  model: string;
  ttsModel: string;
  hasGeminiKey: boolean;
  timestamp: string;
  supportedLanguages: string[];
  voiceSynthesizer: string;
}

export interface ChatResponse {
  reply: string;
  isFallback?: boolean;
  error?: string;
  latency?: number;
  languageDetected?: 'hindi' | 'hinglish' | 'english' | 'auto';
}

export interface TTSResponse {
  fallbackToBrowser: boolean;
  audioData?: string;
  mimeType?: string;
  error?: string;
}

export async function checkServerHealth(): Promise<HealthResponse> {
  const res = await fetch('/api/health');
  if (!res.ok) {
    throw new Error(`Health check failed: ${res.statusText}`);
  }
  return res.json();
}

export async function sendChatMessage(params: {
  message: string;
  history: ChatMessage[];
  languageMode: LanguageMode;
  personality: PersonalityMode;
  assistantName: string;
  userName: string;
}): Promise<ChatResponse> {
  const startTime = performance.now();
  const res = await fetch('/api/chat', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      message: params.message,
      history: params.history.map((m) => ({
        role: m.role,
        content: m.content,
      })),
      languageMode: params.languageMode,
      personality: params.personality,
      assistantName: params.assistantName,
      userName: params.userName,
    }),
  });

  const latency = Math.round(performance.now() - startTime);

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    const detailedMessage = data.reply || data.error || `Server error (${res.status})`;
    throw new Error(detailedMessage);
  }

  return { ...data, latency };
}

export async function requestNeuralTTS(text: string, voiceName: GeminiVoice): Promise<TTSResponse> {
  try {
    const res = await fetch('/api/tts', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text, voiceName }),
    });

    if (!res.ok) {
      return { fallbackToBrowser: true };
    }

    return await res.json();
  } catch (err) {
    console.warn('Neural TTS request failed, fallback to browser speech:', err);
    return { fallbackToBrowser: true };
  }
}
