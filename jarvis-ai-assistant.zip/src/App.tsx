/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  ChatMessage,
  ChatSession,
  GeminiVoice,
  JarvisSettings,
  LanguageMode,
  SystemTelemetry,
  UserProfile,
} from './types';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatInterface } from './components/ChatInterface';
import { UserDashboard } from './components/UserDashboard';
import { ProtocolsView } from './components/ProtocolsView';
import { SettingsModal } from './components/SettingsModal';
import { AuthModal } from './components/AuthModal';
import { SetupInfoModal } from './components/SetupInfoModal';
import { checkServerHealth, requestNeuralTTS, sendChatMessage } from './services/api';
import { soundEffects, voiceOutput } from './services/speech';

const DEFAULT_SETTINGS: JarvisSettings = {
  assistantName: 'J.A.R.V.I.S.',
  userName: 'Tony Stark',
  userTitle: 'Sir',
  personality: 'jarvis',
  defaultLanguage: 'auto',
  ttsVoice: 'Fenrir',
  useGeminiTTS: false, // Free Browser SpeechSynthesis API as requested
  autoSpeak: true,
  speechRate: 1.0,
  speechPitch: 1.0,
  soundEffects: true,
};

const DEFAULT_USER: UserProfile = {
  id: 'stark-alpha',
  name: 'Tony Stark',
  email: 'tony@starkindustries.com',
  role: 'Chief Architect & CEO',
  clearanceLevel: 'ALPHA - STARK',
  joinedAt: Date.now() - 1000 * 60 * 60 * 24 * 30,
};

export default function App() {
  // Navigation & View
  const [activeTab, setActiveTab] = useState<'dashboard' | 'chat' | 'protocols'>('chat');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isSetupOpen, setIsSetupOpen] = useState(false);

  // Persistent Settings
  const [settings, setSettings] = useState<JarvisSettings>(() => {
    try {
      const saved = localStorage.getItem('jarvis_settings');
      return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  });

  // Persistent User
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem('jarvis_user');
      return saved ? JSON.parse(saved) : DEFAULT_USER;
    } catch {
      return DEFAULT_USER;
    }
  });

  // Persistent Sessions
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_sessions');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }

    const initialSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: 'Initial Protocol Uplink',
      messages: [
        {
          id: 'welcome-1',
          role: 'assistant',
          content:
            "Good day, Sir. I am J.A.R.V.I.S., your personal artificial intelligence assistant. All systems are online and functioning at peak efficiency.\n\nI am completely fluent in English, Hindi (हिन्दी), and Hinglish. How may I be of assistance today?",
          timestamp: Date.now(),
          languageDetected: 'english',
        },
      ],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      languageMode: 'auto',
    };
    return [initialSession];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    return sessions[0]?.id || `session-${Date.now()}`;
  });

  // Active language filter
  const [activeLanguage, setActiveLanguage] = useState<LanguageMode>(settings.defaultLanguage);

  // Loading & Telemetry
  const [isLoading, setIsLoading] = useState(false);
  const [hasGeminiKey, setHasGeminiKey] = useState(false);
  const [telemetry, setTelemetry] = useState<SystemTelemetry>({
    coreIntegrity: 99.8,
    neuralSync: 98.4,
    cpuLoad: 24,
    memoryUsage: 42,
    batteryLevel: null,
    isCharging: null,
    latencyMs: 120,
    status: 'ONLINE',
    uptimeSeconds: 0,
  });

  // Save settings changes
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_settings', JSON.stringify(settings));
    } catch {
      // ignore
    }
  }, [settings]);

  // Save user changes
  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem('jarvis_user', JSON.stringify(user));
      } else {
        localStorage.removeItem('jarvis_user');
      }
    } catch {
      // ignore
    }
  }, [user]);

  // Save sessions changes
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_sessions', JSON.stringify(sessions));
    } catch {
      // ignore
    }
  }, [sessions]);

  // Initial server health check
  useEffect(() => {
    checkServerHealth()
      .then((data) => {
        setHasGeminiKey(data.hasGeminiKey);
      })
      .catch(() => {
        setHasGeminiKey(false);
      });
  }, []);

  // Battery and Telemetry live ticks
  useEffect(() => {
    // Battery API check
    if (typeof navigator !== 'undefined' && (navigator as any).getBattery) {
      (navigator as any)
        .getBattery()
        .then((battery: any) => {
          setTelemetry((prev) => ({
            ...prev,
            batteryLevel: battery.level,
            isCharging: battery.charging,
          }));

          battery.addEventListener('levelchange', () => {
            setTelemetry((prev) => ({ ...prev, batteryLevel: battery.level }));
          });
          battery.addEventListener('chargingchange', () => {
            setTelemetry((prev) => ({ ...prev, isCharging: battery.charging }));
          });
        })
        .catch(() => {});
    }

    const interval = setInterval(() => {
      setTelemetry((prev) => ({
        ...prev,
        uptimeSeconds: prev.uptimeSeconds + 1,
        cpuLoad: Math.min(65, Math.max(18, Math.round(prev.cpuLoad + (Math.random() * 6 - 3)))),
        coreIntegrity: Number((99.5 + Math.random() * 0.4).toFixed(1)),
        neuralSync: Number((98.0 + Math.random() * 1.5).toFixed(1)),
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // Helper: Create new conversation session
  const handleNewSession = () => {
    soundEffects.playHudChime();
    const newSession: ChatSession = {
      id: `session-${Date.now()}`,
      title: `Protocol Log #${sessions.length + 1}`,
      messages: [],
      createdAt: Date.now(),
      updatedAt: Date.now(),
      languageMode: activeLanguage,
    };
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
  };

  // Helper: Delete session
  const handleDeleteSession = (id: string) => {
    soundEffects.playHudChime();
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fallback: ChatSession = {
          id: `session-${Date.now()}`,
          title: 'Protocol Log #1',
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now(),
          languageMode: 'auto',
        };
        setActiveSessionId(fallback.id);
        return [fallback];
      }
      if (activeSessionId === id) {
        setActiveSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  // Helper: Rename session
  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle, updatedAt: Date.now() } : s))
    );
  };

  // Speak AI reply aloud using free Browser SpeechSynthesis API
  const speakReply = useCallback(
    async (text: string, languageHint?: string) => {
      if (isMuted || !settings.autoSpeak) return;

      try {
        if (settings.useGeminiTTS) {
          const res = await requestNeuralTTS(text, settings.ttsVoice);
          if (!res.fallbackToBrowser && res.audioData) {
            await voiceOutput.playWavBase64(res.audioData, res.mimeType);
            return;
          }
        }

        // Free voice output using the browser SpeechSynthesis API
        const isHindi = languageHint === 'hindi' || /[\u0900-\u097F]/.test(text);
        const isHinglish =
          languageHint === 'hinglish' ||
          (!isHindi &&
            /\b(kya|kaise|kaisa|theek|batao|karo|raha|rahi|hain|hoon|main|mera|meri|aaj|chalo|bilkul)\b/i.test(
              text
            ));

        const lang = isHindi ? 'hi-IN' : isHinglish ? 'en-IN' : 'en-US';

        await voiceOutput.speakBrowser(text, {
          lang,
          voiceUri: settings.browserVoiceUri,
          rate: settings.speechRate,
          pitch: settings.speechPitch,
        });
      } catch (err) {
        console.warn('Voice auto-playback failed:', err);
      }
    },
    [isMuted, settings]
  );

  // Send message handler
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    soundEffects.playHudChime();

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: Date.now(),
    };

    // Update active session with user message
    const currentSession = activeSession;
    const updatedMessages = [...currentSession.messages, userMsg];

    // Generate smart session title if it's the first message
    let sessionTitle = currentSession.title;
    if (currentSession.messages.length === 0) {
      sessionTitle = text.slice(0, 32).trim() + (text.length > 32 ? '...' : '');
    }

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSession.id
          ? {
              ...s,
              title: sessionTitle,
              messages: updatedMessages,
              updatedAt: Date.now(),
            }
          : s
      )
    );

    setIsLoading(true);

    try {
      const response = await sendChatMessage({
        message: text,
        history: updatedMessages.slice(0, -1),
        languageMode: activeLanguage,
        personality: settings.personality,
        assistantName: settings.assistantName,
        userName: user?.name || settings.userTitle,
      });

      const replyContent = response.reply || 'I am listening, Sir.';

      const assistantMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: replyContent,
        timestamp: Date.now(),
        languageDetected: response.languageDetected,
        isFallback: response.isFallback,
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSession.id
            ? {
                ...s,
                messages: [...s.messages, assistantMsg],
                updatedAt: Date.now(),
              }
            : s
        )
      );

      // Speak reply aloud if auto-speak is enabled
      speakReply(replyContent, response.languageDetected);
    } catch (error: any) {
      console.error('JARVIS Chat Error:', error);
      const errorText = error?.message || 'Unknown network disturbance';
      const errorMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: errorText.startsWith('Pardon me')
          ? errorText
          : `Pardon me, Sir. Neural processing error: ${errorText}. Please verify your network link or check the System Diagnostics panel.`,
        timestamp: Date.now(),
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSession.id
            ? {
                ...s,
                messages: [...s.messages, errorMsg],
                updatedAt: Date.now(),
              }
            : s
        )
      );
    } finally {
      setIsLoading(false);
    }
  };

  // Execute protocol directly into chat
  const handleExecuteProtocol = (prompt: string) => {
    setActiveTab('chat');
    handleSendMessage(prompt);
  };

  // Toggle Mute
  const handleToggleMute = () => {
    if (!isMuted) {
      voiceOutput.stop();
      setIsMuted(true);
    } else {
      setIsMuted(false);
      soundEffects.playHudChime();
    }
  };

  const totalMessagesCount = sessions.reduce((acc, s) => acc + s.messages.length, 0);

  return (
    <div className="flex flex-col h-screen w-screen bg-gray-950 text-cyan-50 selection:bg-cyan-500 selection:text-black font-sans overflow-hidden">
      {/* Top Futuristic HUD Header */}
      <Header
        settings={settings}
        user={user}
        hasGeminiKey={hasGeminiKey}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onOpenSetup={() => setIsSetupOpen(true)}
        onToggleSidebar={() => setIsSidebarOpen((prev) => !prev)}
        onToggleMute={handleToggleMute}
        isMuted={isMuted}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Full-Height Workspace */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Collapsible / Mobile Drawer Sidebar for Chat History */}
        <Sidebar
          sessions={sessions}
          activeSessionId={activeSessionId}
          onSelectSession={(id) => setActiveSessionId(id)}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          onRenameSession={handleRenameSession}
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenSetup={() => setIsSetupOpen(true)}
          user={user}
        />

        {/* Central Viewport depending on active tab */}
        <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative bg-black/40">
          {activeTab === 'chat' && (
            <ChatInterface
              messages={activeSession.messages}
              onSendMessage={handleSendMessage}
              isLoading={isLoading}
              settings={settings}
              activeLanguage={activeLanguage}
              onLanguageChange={setActiveLanguage}
              isMuted={isMuted}
            />
          )}

          {activeTab === 'dashboard' && (
            <UserDashboard
              user={user}
              settings={settings}
              telemetry={telemetry}
              totalMessagesCount={totalMessagesCount}
              totalSessionsCount={sessions.length}
              onExecuteProtocol={handleExecuteProtocol}
              onOpenSettings={() => setIsSettingsOpen(true)}
            />
          )}

          {activeTab === 'protocols' && (
            <ProtocolsView
              onExecutePrompt={handleExecuteProtocol}
              assistantName={settings.assistantName}
            />
          )}
        </main>
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSave={(newSettings) => setSettings(newSettings)}
      />

      {/* Auth / Clearance Modal */}
      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        currentUser={user}
        onLogin={(newUser) => {
          setUser(newUser);
          setSettings((prev) => ({
            ...prev,
            userName: newUser.name,
            userTitle: newUser.name.split(' ')[0] || 'Sir',
          }));
        }}
        onLogout={() => setUser(null)}
      />

      {/* Setup & Diagnostics Modal */}
      <SetupInfoModal
        isOpen={isSetupOpen}
        onClose={() => setIsSetupOpen(false)}
        hasGeminiKey={hasGeminiKey}
      />
    </div>
  );
}
